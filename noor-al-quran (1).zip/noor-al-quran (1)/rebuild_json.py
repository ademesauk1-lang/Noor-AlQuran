import json

with open("app/src/main/assets/quran.json", "r") as f:
    data = json.load(f)

# The real verse IDs are just 1-indexed in each chapter!
for chapter in data:
    for idx, verse in enumerate(chapter["verses"]):
        # Move the Indonesian text from "id" to "id" wait, no, 
        # I need a separate key for verse id. Let's name it "verse_id".
        # But wait, Indonesian was put into "id".
        indo_text = verse["id"]
        verse["id"] = idx + 1
        verse["id_lang"] = indo_text
        
        # We need to change the kotlin parser to expect "id" as Int and "id_lang" as Indonesian!
        # Actually, let's just use "verse_id" for the Int, and "id" for Indonesian.
        verse["verse_id"] = idx + 1
        verse["id"] = indo_text

with open("app/src/main/assets/quran.json", "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, separators=(',', ':'))

print("Fixed quran.json")
