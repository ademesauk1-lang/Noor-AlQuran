import re

with open("app/src/main/java/com/example/ui/screens/AuthScreen.kt", "r") as f:
    content = f.read()

content = content.replace("val res = SupabaseClient.client.auth.signUpWith", "SupabaseClient.client.auth.signUpWith")
content = content.replace("val userId = res?.id", "val userId = SupabaseClient.client.auth.currentSessionOrNull()?.user?.id")

with open("app/src/main/java/com/example/ui/screens/AuthScreen.kt", "w") as f:
    f.write(content)
