import re

with open("app/src/main/java/com/example/data/model/QuranModels.kt", "r") as f:
    content = f.read()

new_enum = """
enum class BackgroundSound(val displayName: String, val audioUrl: String?) {
    NONE("None", null),
    RAIN("Rain", "https://cdn.pixabay.com/download/audio/2021/08/04/audio_3d1a550978.mp3"),
    NATURE("Nature", "https://cdn.pixabay.com/download/audio/2022/01/18/audio_d0a13f69d2.mp3"),
    BROWN_NOISE("Brown Noise", "https://cdn.pixabay.com/download/audio/2022/10/24/audio_dc7ab2d634.mp3"),
    FIREPLACE("Fireplace", "https://cdn.pixabay.com/download/audio/2022/03/15/audio_2491a62779.mp3"),
    OCEAN("Ocean", "https://cdn.pixabay.com/download/audio/2022/02/10/audio_fc862140bb.mp3")
}
"""

content = content + new_enum

with open("app/src/main/java/com/example/data/model/QuranModels.kt", "w") as f:
    f.write(content)
