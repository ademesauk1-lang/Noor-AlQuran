import re

with open("app/src/main/java/com/example/ui/screens/RecitersScreen.kt", "r") as f:
    content = f.read()

# Make sure AsyncImage is imported
if "import coil.compose.AsyncImage" not in content:
    content = content.replace("import androidx.compose.ui.Modifier", "import androidx.compose.ui.Modifier\nimport coil.compose.AsyncImage\nimport androidx.compose.ui.layout.ContentScale\nimport androidx.compose.ui.draw.clip")

old_qari_row = """        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(56.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = qari.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "${qari.country} • Full Quran",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFA0A0AB)
                )
            }"""

new_qari_row = """        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = qari.photoUrl,
                contentDescription = qari.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = qari.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "${qari.country} • Full Quran",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFA0A0AB)
                )
            }"""

content = content.replace(old_qari_row, new_qari_row)

with open("app/src/main/java/com/example/ui/screens/RecitersScreen.kt", "w") as f:
    f.write(content)

