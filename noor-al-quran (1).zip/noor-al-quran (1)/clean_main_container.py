with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    text = f.read()

# Find package declaration
pkg_token = "package com.example.ui.screens"
if pkg_token in text:
    pkg_index = text.find(pkg_token)
    text = text[pkg_index:] # Drop everything before package

# Ensure imports are clean after package
imports = """package com.example.ui.screens

import coil.compose.AsyncImage
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip"""

text = text.replace("package com.example.ui.screens", imports, 1)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(text)

print("MainContainerScreen header cleaned")
