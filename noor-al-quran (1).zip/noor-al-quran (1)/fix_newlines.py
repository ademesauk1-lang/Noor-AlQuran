import re

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    content = f.read()

# Insert newlines before keywords
content = re.sub(r'([^\n])(package )', r'\1\n\2', content)
content = re.sub(r'([^\n])(import )', r'\1\n\2', content)
content = re.sub(r'([^\n])(@Composable)', r'\1\n\2', content)
content = re.sub(r'([^\n])(fun )', r'\1\n\2', content)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(content)

print("Newlines added")
