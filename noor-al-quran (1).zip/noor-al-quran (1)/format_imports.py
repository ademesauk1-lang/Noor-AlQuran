with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    text = f.read()

text = text.replace("import ", "\nimport ")
text = text.replace("package ", "\npackage ")

# Remove duplicate blank lines
lines = [line.strip() for line in text.splitlines() if line.strip()]

# Reconstruct
new_lines = []
for line in lines:
    if line.startswith("package "):
        new_lines.insert(0, line)
    else:
        new_lines.append(line)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write("\n".join(new_lines))

print("Formatted imports")
