import re

with open("app/src/main/java/com/example/ui/screens/PremiumUnlockScreen.kt", "r") as f:
    content = f.read()

features_orig = """                val features = listOf(
                    PremiumFeatureItem("Background sounds", Icons.Default.GraphicEq),
                    PremiumFeatureItem("All Surahs Downloadable", Icons.Default.Download),
                    PremiumFeatureItem("Advanced Tafsir & Word-by-Word", Icons.Default.AutoAwesome),
                    PremiumFeatureItem("Ad-Free Experience", Icons.Default.Block),
                    PremiumFeatureItem("Android Auto Support", Icons.Default.DirectionsCar),
                    PremiumFeatureItem("Background Audio Control", Icons.Default.Headphones)
                )"""
features_new = """                val features = listOf(
                    PremiumFeatureItem("Unlock All Translations", Icons.Default.AutoAwesome),
                    PremiumFeatureItem("Unlock All Reciters", Icons.Default.GraphicEq),
                    PremiumFeatureItem("Background sounds", Icons.Default.GraphicEq),
                    PremiumFeatureItem("All Surahs Downloadable", Icons.Default.Download),
                    PremiumFeatureItem("Ad-Free Experience", Icons.Default.Block),
                    PremiumFeatureItem("Background Audio Control", Icons.Default.Headphones)
                )"""

content = content.replace(features_orig, features_new)

with open("app/src/main/java/com/example/ui/screens/PremiumUnlockScreen.kt", "w") as f:
    f.write(content)
