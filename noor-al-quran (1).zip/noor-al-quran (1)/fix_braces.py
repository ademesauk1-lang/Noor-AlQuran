with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    content = f.read()

target = """                            modifier = Modifier.testTag(item.testTag)
                        )
                    }
                }
            }
        }
    ) { paddingValues ->"""

replacement = """                            modifier = Modifier.testTag(item.testTag)
                        )
                    }
                }
                }
            }
        }
    ) { paddingValues ->"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(content)
