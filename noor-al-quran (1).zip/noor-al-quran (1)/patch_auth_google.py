import re

with open("app/src/main/java/com/example/ui/screens/AuthScreen.kt", "r") as f:
    content = f.read()

# Add Google Auth Button
button_code = """
            Button(
                onClick = {
                    // Start Google Sign In via Supabase
                    isLoading = true
                    scope.launch {
                        try {
                            SupabaseClient.client.auth.signInWith(io.github.jan.supabase.gotrue.providers.Google)
                            isLoading = false
                            onNavigateHome()
                        } catch(e: Exception) {
                            isLoading = false
                            Toast.makeText(context, e.message ?: "Google Auth failed", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = cardBackground),
                enabled = !isLoading
            ) {
                Text(
                    text = "Sign in with Google",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = textWhite
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
"""

target = "Spacer(modifier = Modifier.height(24.dp))"
idx = content.find(target)
if idx != -1:
    content = content[:idx] + button_code + content[idx+len(target):]

with open("app/src/main/java/com/example/ui/screens/AuthScreen.kt", "w") as f:
    f.write(content)
