import re

with open("app/build.gradle.kts", "r") as f:
    content = f.read()

content = content.replace("implementation(\"io.github.jan-tennert.supabase:gotrue-kt\")", "implementation(\"io.github.jan-tennert.supabase:auth-kt\")")

with open("app/build.gradle.kts", "w") as f:
    f.write(content)
