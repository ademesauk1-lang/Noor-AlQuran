import re

with open("app/src/main/AndroidManifest.xml", "r") as f:
    content = f.read()

# Add attribution tag
if "<attribution" not in content:
    content = content.replace("</manifest>", "    <attribution android:tag=\"general\" android:label=\"@string/app_name\" />\n</manifest>")

with open("app/src/main/AndroidManifest.xml", "w") as f:
    f.write(content)
