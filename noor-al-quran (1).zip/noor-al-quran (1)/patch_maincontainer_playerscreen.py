import re

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    content = f.read()

target = """                AppTab.PLAYER -> PlayerScreen(
                    uiState = uiState,
                    onTogglePlayPause = { viewModel.togglePlayPause() },
                    onNextTrack = { viewModel.nextAudioTrack() },
                    onPreviousTrack = { viewModel.previousAudioTrack() },
                    onSeekAudio = { viewModel.seekAudio(it) },
                    onSelectQari = { viewModel.selectQari(it) },
                    onToggleLoop = { viewModel.toggleLoopSurah() },
                    onToggleSpeed = { viewModel.togglePlaybackSpeed() },
                    onNavigateToPremium = { viewModel.selectTab(AppTab.PREMIUM) }
                )"""

replacement = """                AppTab.PLAYER -> PlayerScreen(
                    uiState = uiState,
                    onTogglePlayPause = { viewModel.togglePlayPause() },
                    onNextTrack = { viewModel.nextAudioTrack() },
                    onPreviousTrack = { viewModel.previousAudioTrack() },
                    onSeekAudio = { viewModel.seekAudio(it) },
                    onSelectQari = { viewModel.selectQari(it) },
                    onToggleLoop = { viewModel.toggleLoopSurah() },
                    onToggleSpeed = { viewModel.togglePlaybackSpeed() },
                    onSelectBackgroundSound = { viewModel.setBackgroundSound(it) },
                    onNavigateToPremium = { viewModel.selectTab(AppTab.PREMIUM) }
                )"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(content)
