import os

files = ["app/src/main/java/com/example/data/api/SupabaseClient.kt", "app/src/main/java/com/example/ui/screens/AuthScreen.kt"]

for file in files:
    with open(file, "r") as f:
        content = f.read()
    
    content = content.replace("io.github.jan.supabase.gotrue.GoTrue", "io.github.jan.supabase.auth.Auth")
    content = content.replace("install(GoTrue)", "install(Auth)")
    content = content.replace("io.github.jan.supabase.gotrue.auth", "io.github.jan.supabase.auth.auth")
    content = content.replace("io.github.jan.supabase.gotrue.providers.builtin.Email", "io.github.jan.supabase.auth.providers.builtin.Email")
    content = content.replace("io.github.jan.supabase.gotrue.providers.Google", "io.github.jan.supabase.auth.providers.Google")
    
    with open(file, "w") as f:
        f.write(content)

