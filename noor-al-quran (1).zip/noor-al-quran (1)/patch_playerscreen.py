import re

with open("app/src/main/java/com/example/ui/screens/PlayerScreen.kt", "r") as f:
    content = f.read()

# Update signature
signature_orig = """fun PlayerScreen(
    uiState: QuranUiState,
    onTogglePlayPause: () -> Unit,
    onNextTrack: () -> Unit,
    onPreviousTrack: () -> Unit,
    onSeekAudio: (Float) -> Unit,
    onSelectQari: (Qari) -> Unit,
    onToggleLoop: () -> Unit,
    onToggleSpeed: () -> Unit,
    onNavigateToPremium: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {"""
signature_new = """fun PlayerScreen(
    uiState: QuranUiState,
    onTogglePlayPause: () -> Unit,
    onNextTrack: () -> Unit,
    onPreviousTrack: () -> Unit,
    onSeekAudio: (Float) -> Unit,
    onSelectQari: (Qari) -> Unit,
    onToggleLoop: () -> Unit,
    onToggleSpeed: () -> Unit,
    onSelectBackgroundSound: (com.example.data.model.BackgroundSound) -> Unit = {},
    onNavigateToPremium: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {"""
content = content.replace(signature_orig, signature_new)

# Add showSoundSheet state
state_orig = "    var showQariDropdown by remember { mutableStateOf(false) }"
state_new = "    var showQariDropdown by remember { mutableStateOf(false) }\n    var showSoundSheet by remember { mutableStateOf(false) }"
content = content.replace(state_orig, state_new)

# Add sound options button in audio controls
audio_controls_orig = """            IconButton(
                onClick = onToggleSpeed,
                modifier = Modifier.size(48.dp)
            ) {
                Text(
                    text = "${uiState.playbackSpeed}x",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}"""
audio_controls_new = """            IconButton(
                onClick = onToggleSpeed,
                modifier = Modifier.size(48.dp)
            ) {
                Text(
                    text = "${uiState.playbackSpeed}x",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(
                onClick = { showSoundSheet = true },
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = "Background Sound",
                    tint = if (uiState.backgroundSound != com.example.data.model.BackgroundSound.NONE) GoldAccentLight else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        
        if (showSoundSheet) {
            androidx.compose.material3.ModalBottomSheet(
                onDismissRequest = { showSoundSheet = false },
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Background Sound Options",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    val sounds = com.example.data.model.BackgroundSound.entries
                    sounds.chunked(3).forEach { rowSounds ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            rowSounds.forEach { sound ->
                                val isSelected = uiState.backgroundSound == sound
                                OutlinedButton(
                                    onClick = { 
                                        onSelectBackgroundSound(sound)
                                        showSoundSheet = false
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                                    ),
                                    modifier = Modifier.padding(4.dp)
                                ) {
                                    Text(
                                        text = sound.displayName,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}"""
content = content.replace(audio_controls_orig, audio_controls_new)

# we need to ensure MusicNote icon is imported
if "import androidx.compose.material.icons.filled.MusicNote" not in content:
    content = content.replace("import androidx.compose.material.icons.filled.Pause", "import androidx.compose.material.icons.filled.Pause\nimport androidx.compose.material.icons.filled.MusicNote")

with open("app/src/main/java/com/example/ui/screens/PlayerScreen.kt", "w") as f:
    f.write(content)
