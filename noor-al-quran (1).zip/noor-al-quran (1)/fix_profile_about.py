import re

with open("app/src/main/java/com/example/ui/screens/ProfileScreen.kt", "r") as f:
    content = f.read()

content = content.replace("onNavigateToTab(AppTab.ABOUT)", "onNavigateToTab?.invoke(com.example.data.model.AppTab.ABOUT)")

with open("app/src/main/java/com/example/ui/screens/ProfileScreen.kt", "w") as f:
    f.write(content)
