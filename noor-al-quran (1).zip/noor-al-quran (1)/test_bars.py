import re
with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    content = f.read()

# I want to wrap topBar and bottomBar in if conditions
if "val showTopAndBottomBar = uiState.currentTab !in listOf(AppTab.WELCOME, AppTab.PREMIUM, AppTab.AUTH, AppTab.AUTH_CALLBACK, AppTab.ABOUT, AppTab.THEME_LAB)" not in content:
    content = content.replace("    Scaffold(", "    val showTopAndBottomBar = uiState.currentTab !in listOf(AppTab.WELCOME, AppTab.PREMIUM, AppTab.AUTH, AppTab.AUTH_CALLBACK, AppTab.ABOUT, AppTab.THEME_LAB, AppTab.READER, AppTab.PLAYER)\n    Scaffold(")
    content = content.replace("        topBar = {", "        topBar = {\n            if (showTopAndBottomBar) {")
    # need to find end of topBar to add }
    # but maybe topBar doesn't have an explicit return? No, TopAppBar is just invoked.
print(content[:300])
