import re

with open("app/src/main/java/com/example/ui/screens/PremiumUnlockScreen.kt", "r") as f:
    content = f.read()

btn_pattern = r"            // Top Close / Back Button\n            IconButton\(\n                onClick = onDismiss,\n                modifier = Modifier\n                    \.padding\(top = 12\.dp, start = 12\.dp\)\n                    \.align\(Alignment\.TopStart\)\n                    \.testTag\(\"premium_close_button\"\)\n            \) \{\n                Icon\(\n                    imageVector = Icons\.Default\.Close,\n                    contentDescription = \"Close Premium Screen\",\n                    tint = Color\.White\n                \)\n            \}\n"

btn_code = """            // Top Close / Back Button
            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .padding(top = 12.dp, start = 12.dp)
                    .align(Alignment.TopStart)
                    .testTag("premium_close_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close Premium Screen",
                    tint = Color.White
                )
            }
"""

content = re.sub(btn_pattern, "", content)

# insert before the final 2 closing braces of PremiumUnlockScreen (the outer Box and the function)
content = content.replace("        // Features List\n        Column", btn_code + "        // Features List\n        Column")

# Wait, the end of the outer Box is right before the SubscriptionPlanCard composable. Let's find `@Composable\nprivate fun SubscriptionPlanCard`.
content = content.replace("@Composable\nprivate fun SubscriptionPlanCard", btn_code + "    }\n}\n\n@Composable\nprivate fun SubscriptionPlanCard")
# But we need to remove the closing braces of PremiumUnlockScreen that we just bypassed...
# It's better to just use replace to precisely target the end of PremiumUnlockScreen.
