import re

with open("app/src/main/java/com/example/data/repository/QuranData.kt", "r") as f:
    text = f.read()

# Replace the initialize method and getAyahsForSurah method
new_code = """
    private var allAyahsCache: Map<Int, List<Ayah>>? = null

    fun initialize(context: android.content.Context) {
        if (allAyahsCache != null) return
        
        try {
            val inputStream = context.assets.open("quran.json")
            val size = inputStream.available()
            val buffer = ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()
            val jsonString = String(buffer, Charsets.UTF_8)
            
            val jsonArray = org.json.JSONArray(jsonString)
            val cache = mutableMapOf<Int, List<Ayah>>()
            
            for (i in 0 until jsonArray.length()) {
                val surahObj = jsonArray.getJSONObject(i)
                val surahId = surahObj.getInt("id")
                val versesArray = surahObj.getJSONArray("verses")
                
                val ayahs = mutableListOf<Ayah>()
                for (j in 0 until versesArray.length()) {
                    val verseObj = versesArray.getJSONObject(j)
                    val ayahNum = verseObj.getInt("id")
                    val textArabic = verseObj.getString("ar")
                    
                    val translations = mutableMapOf<String, String>()
                    val keys = verseObj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        if (key != "id" && key != "ar") {
                            translations[key] = verseObj.getString(key)
                        }
                    }
                    
                    ayahs.add(Ayah(
                        surahNumber = surahId,
                        ayahNumber = ayahNum,
                        textArabic = textArabic,
                        translations = translations
                    ))
                }
                cache[surahId] = ayahs
            }
            allAyahsCache = cache
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getAyahsForSurah(surahId: Int): List<Ayah> {
        return allAyahsCache?.get(surahId) ?: emptyList()
    }
}
"""

start_idx = text.find("    private var allAyahsCache")
if start_idx == -1:
    print("Could not find allAyahsCache")
else:
    text = text[:start_idx] + new_code
    with open("app/src/main/java/com/example/data/repository/QuranData.kt", "w") as f:
        f.write(text)
