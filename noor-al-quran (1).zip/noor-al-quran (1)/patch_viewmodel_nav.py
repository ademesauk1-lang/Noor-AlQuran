import re

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "r") as f:
    content = f.read()

nav_logic = """    private val tabStack = mutableListOf<AppTab>()

    fun navigateToPremium() {
        tabStack.add(_uiState.value.currentTab)
        _uiState.update { it.copy(currentTab = AppTab.PREMIUM) }
    }
    
    fun navigateToAuth() {
        tabStack.add(_uiState.value.currentTab)
        _uiState.update { it.copy(currentTab = AppTab.AUTH) }
    }

    fun popBackStack() {
        if (tabStack.isNotEmpty()) {
            val previous = tabStack.removeLast()
            _uiState.update { it.copy(currentTab = previous) }
        } else {
            _uiState.update { it.copy(currentTab = AppTab.HOME) }
        }
    }
"""
idx = content.find("fun selectTab(tab: AppTab) {")
if idx != -1:
    content = content[:idx] + nav_logic + "\n" + content[idx:]

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    main_content = f.read()

main_content = main_content.replace(
    "onDismiss = { viewModel.selectTab(AppTab.HOME) }",
    "onDismiss = { viewModel.popBackStack() }"
)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(main_content)

