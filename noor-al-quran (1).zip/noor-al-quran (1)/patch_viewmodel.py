import re

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "r") as f:
    content = f.read()

# Modify loadPreferences
load_pref_start = "    private fun loadPreferences() {"
new_load_pref = load_pref_start + """
        val hasSeenWelcome = prefs.getBoolean("has_seen_welcome", false)"""

content = content.replace(load_pref_start, new_load_pref)

update_state_start = """        _uiState.update {
            it.copy(
                bookmarkedAyahs = savedBookmarks,"""

new_update_state = """        val initialTab = if (hasSeenWelcome) AppTab.HOME else AppTab.WELCOME
        _uiState.update {
            it.copy(
                currentTab = initialTab,
                bookmarkedAyahs = savedBookmarks,"""
                
content = content.replace(update_state_start, new_update_state)

# Add completeWelcome function
new_function = """    fun completeWelcome() {
        prefs.edit().putBoolean("has_seen_welcome", true).apply()
        _uiState.update { it.copy(currentTab = AppTab.HOME) }
    }

    fun popBackStack() {"""

content = content.replace("    fun popBackStack() {", new_function)

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "w") as f:
    f.write(content)

