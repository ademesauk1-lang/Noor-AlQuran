import re

with open("app/src/main/java/com/example/ui/screens/PremiumUnlockScreen.kt", "r") as f:
    content = f.read()

btn_pattern = r"            // Top Close / Back Button\s*IconButton\(\s*onClick = onDismiss,[\s\S]*?            }\n"

match = re.search(btn_pattern, content)
if match:
    btn_code = match.group(0)
    # Remove it
    content = content.replace(btn_code, "")
    
    # Insert it right before the last closing brace of the PremiumUnlockScreen
    # It ends with:
    #             Spacer(modifier = Modifier.height(24.dp))
    #         }
    #     }
    # }
    
    insert_target = "            Spacer(modifier = Modifier.height(24.dp))\n        }\n"
    replacement = insert_target + btn_code
    
    content = content.replace(insert_target, replacement)
    
    with open("app/src/main/java/com/example/ui/screens/PremiumUnlockScreen.kt", "w") as f:
        f.write(content)
