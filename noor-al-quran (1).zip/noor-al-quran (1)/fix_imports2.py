import re

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    s = f.read()

s = re.sub(r'import', r'\nimport', s)
s = re.sub(r'package', r'\npackage', s)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(s.strip())

print("Done")
