import re

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "r") as f:
    content = f.read()

imports = """
import io.github.jan.supabase.auth.status.SessionStatus
import com.example.data.api.SupabaseClient
import com.example.data.model.UserProfile
import io.github.jan.supabase.postgrest.postgrest
"""

if "import io.github.jan.supabase.auth.status.SessionStatus" not in content:
    content = content.replace("import androidx.lifecycle.ViewModel", "import androidx.lifecycle.ViewModel\n" + imports)

# Find init block
init_idx = content.find("init {")
if init_idx != -1:
    session_listener = """
        viewModelScope.launch {
            SupabaseClient.client.auth.sessionStatus.collect { status ->
                when (status) {
                    is SessionStatus.Authenticated -> {
                        val userId = status.session.user?.id ?: return@collect
                        try {
                            val profile = SupabaseClient.client.postgrest["profiles"]
                                .select { filter { eq("id", userId) } }
                                .decodeSingleOrNull<UserProfile>()
                                
                            if (profile != null) {
                                // Sync reading progress
                                if (profile.last_read_surah != null && profile.last_read_ayah != null) {
                                    val newLastRead = _uiState.value.lastRead.copy(
                                        surahId = profile.last_read_surah,
                                        ayahNumber = profile.last_read_ayah
                                    )
                                    _uiState.update { it.copy(lastRead = newLastRead) }
                                }
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                    else -> {}
                }
            }
        }
"""
    # Insert right after `init {`
    insert_pos = init_idx + 6
    content = content[:insert_pos] + session_listener + content[insert_pos:]

# Update `updateLastReadAyah`
update_ayah_code = """    fun updateLastReadAyah(ayahNumber: Int) {
        val current = _uiState.value.lastRead
        if (current.ayahNumber == ayahNumber) return
        val newLastRead = current.copy(ayahNumber = ayahNumber, timestampMs = System.currentTimeMillis())
        prefs.edit().putInt("last_ayah_num", ayahNumber).apply()
        _uiState.update { it.copy(lastRead = newLastRead) }
        
        // Sync to Supabase
        viewModelScope.launch {
            val session = SupabaseClient.client.auth.currentSessionOrNull()
            val userId = session?.user?.id ?: return@launch
            try {
                val profile = UserProfile(id = userId, last_read_surah = newLastRead.surahId, last_read_ayah = newLastRead.ayahNumber)
                SupabaseClient.client.postgrest["profiles"].upsert(profile)
            } catch(e: Exception) {
                e.printStackTrace()
            }
        }
    }"""
    
content = re.sub(r'    fun updateLastReadAyah\(ayahNumber: Int\) \{.*?\n    \}', update_ayah_code, content, flags=re.DOTALL)

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "w") as f:
    f.write(content)
