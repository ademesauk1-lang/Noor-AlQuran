import re

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "r") as f:
    content = f.read()

# Add bgMediaPlayer
content = content.replace("    private var mediaPlayer: MediaPlayer? = null", "    private var mediaPlayer: MediaPlayer? = null\n    private var bgMediaPlayer: MediaPlayer? = null")

# When setting backgroundSound
function_str = """
    fun setBackgroundSound(sound: com.example.data.model.BackgroundSound) {
        _uiState.update { it.copy(backgroundSound = sound) }
        prefs.edit().putString("background_sound", sound.name).apply()
        
        bgMediaPlayer?.release()
        bgMediaPlayer = null
        
        if (sound.audioUrl != null && _uiState.value.isPlaying) {
            bgMediaPlayer = MediaPlayer().apply {
                setDataSource(sound.audioUrl)
                isLooping = true
                setVolume(0.3f, 0.3f)
                setOnPreparedListener { mp ->
                    mp.start()
                }
                prepareAsync()
            }
        }
    }
"""
content = content.replace("    fun toggleLoopSurah() {", function_str + "    fun toggleLoopSurah() {")

# Modify togglePlayPause to handle bgMediaPlayer
toggle_play_pause_orig = """    fun togglePlayPause() {
        val player = mediaPlayer
        if (player != null) {
            try {
                if (player.isPlaying) {
                    player.pause()
                    _uiState.update { it.copy(isPlaying = false) }
                } else {
                    player.start()
                    _uiState.update { it.copy(isPlaying = true) }
                    startProgressTimer()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }"""
    
toggle_play_pause_new = """    fun togglePlayPause() {
        val player = mediaPlayer
        if (player != null) {
            try {
                if (player.isPlaying) {
                    player.pause()
                    bgMediaPlayer?.pause()
                    _uiState.update { it.copy(isPlaying = false) }
                } else {
                    player.start()
                    if (bgMediaPlayer != null) {
                        bgMediaPlayer?.start()
                    } else {
                        val currentBg = _uiState.value.backgroundSound
                        if (currentBg.audioUrl != null) {
                            bgMediaPlayer = MediaPlayer().apply {
                                setDataSource(currentBg.audioUrl)
                                isLooping = true
                                setVolume(0.3f, 0.3f)
                                setOnPreparedListener { mp -> mp.start() }
                                prepareAsync()
                            }
                        }
                    }
                    _uiState.update { it.copy(isPlaying = true) }
                    startProgressTimer()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }"""
content = content.replace(toggle_play_pause_orig, toggle_play_pause_new)

# Stop bgMediaPlayer in release
content = content.replace("""    override fun onCleared() {
        super.onCleared()
        mediaPlayer?.release()
        mediaPlayer = null""", """    override fun onCleared() {
        super.onCleared()
        mediaPlayer?.release()
        mediaPlayer = null
        bgMediaPlayer?.release()
        bgMediaPlayer = null""")
        
# also in loadPreferences:
load_prefs_orig = """        val isPremium = prefs.getBoolean("is_premium_user", false)"""
load_prefs_new = """        val isPremium = prefs.getBoolean("is_premium_user", false)
        val bgSoundName = prefs.getString("background_sound", "NONE") ?: "NONE"
        val bgSound = com.example.data.model.BackgroundSound.valueOf(bgSoundName)"""
content = content.replace(load_prefs_orig, load_prefs_new)

load_prefs_update_orig = """                isPremiumUser = isPremium,"""
load_prefs_update_new = """                isPremiumUser = isPremium,
                backgroundSound = bgSound,"""
content = content.replace(load_prefs_update_orig, load_prefs_update_new)

# Play bg when track changes
play_audio_prepare = """                setOnPreparedListener { mp ->
                    mp.start()
                    applyPlaybackSpeed(_uiState.value.playbackSpeed)"""
                    
play_audio_prepare_new = """                setOnPreparedListener { mp ->
                    mp.start()
                    val currentBg = _uiState.value.backgroundSound
                    if (currentBg.audioUrl != null && bgMediaPlayer == null) {
                        bgMediaPlayer = MediaPlayer().apply {
                            setDataSource(currentBg.audioUrl)
                            isLooping = true
                            setVolume(0.3f, 0.3f)
                            setOnPreparedListener { bgMp -> bgMp.start() }
                            prepareAsync()
                        }
                    } else if (bgMediaPlayer != null && bgMediaPlayer?.isPlaying == false) {
                        bgMediaPlayer?.start()
                    }
                    applyPlaybackSpeed(_uiState.value.playbackSpeed)"""
content = content.replace(play_audio_prepare, play_audio_prepare_new)

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "w") as f:
    f.write(content)

