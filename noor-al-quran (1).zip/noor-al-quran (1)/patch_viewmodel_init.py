import re

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "r") as f:
    content = f.read()

target = "    init {"
replacement = "    init {\n        com.example.data.repository.QuranData.initialize(application)"
if "QuranData.initialize" not in content:
    content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "w") as f:
    f.write(content)
