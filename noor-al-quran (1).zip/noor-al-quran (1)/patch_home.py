with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    text = f.read()

import re

old_daily = """    val dailyAyah = QuranData.getAyahsForSurah(2).find { it.ayahNumber == 255 } 
        ?: QuranData.getAyahsForSurah(1)[0]"""

new_daily = """    val dailyAyah = QuranData.getAyahsForSurah(2).find { it.ayahNumber == 255 } 
        ?: QuranData.getAyahsForSurah(1).firstOrNull() 
        ?: com.example.data.model.Ayah(1, 1, "Data loading error", emptyMap())"""

text = text.replace(old_daily, new_daily)
# Just in case whitespace is different:
text = re.sub(r'val dailyAyah = QuranData\.getAyahsForSurah\(2\)\.find \{ it\.ayahNumber == 255 \}\s*\?\: QuranData\.getAyahsForSurah\(1\)\[0\]', new_daily, text, flags=re.DOTALL)

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "w") as f:
    f.write(text)
