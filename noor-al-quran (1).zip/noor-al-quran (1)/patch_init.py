with open("app/src/main/java/com/example/data/repository/QuranData.kt", "r") as f:
    text = f.read()

import re

old_read = """            val inputStream = context.assets.open("quran.json")
            val size = inputStream.available()
            val buffer = ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()
            val jsonString = String(buffer, Charsets.UTF_8)"""

new_read = """            val jsonString = context.assets.open("quran.json").bufferedReader().use { it.readText() }"""

text = text.replace(old_read, new_read)

with open("app/src/main/java/com/example/data/repository/QuranData.kt", "w") as f:
    f.write(text)
