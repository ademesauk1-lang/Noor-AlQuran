import urllib.request
import json
import ssl

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def fetch(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, context=ctx) as response:
        return json.loads(response.read().decode())

try:
    print("Downloading Arabic text...")
    ar_data = fetch("http://api.alquran.cloud/v1/quran/quran-uthmani")["data"]["surahs"]

    print("Downloading English translation...")
    en_data = fetch("http://api.alquran.cloud/v1/quran/en.asad")["data"]["surahs"]
    
    print("Downloading French translation...")
    fr_data = fetch("http://api.alquran.cloud/v1/quran/fr.hamidullah")["data"]["surahs"]
    
    print("Downloading Indonesian translation...")
    id_data = fetch("http://api.alquran.cloud/v1/quran/id.indonesian")["data"]["surahs"]

    output = []
    
    for i in range(114):
        surah = {
            "id": i + 1,
            "name_ar": ar_data[i]["name"],
            "name_en": ar_data[i]["englishName"],
            "verses": []
        }
        
        ar_ayahs = ar_data[i]["ayahs"]
        en_ayahs = en_data[i]["ayahs"]
        fr_ayahs = fr_data[i]["ayahs"]
        id_ayahs = id_data[i]["ayahs"]
        
        for j in range(len(ar_ayahs)):
            verse = {
                "verse_id": ar_ayahs[j]["numberInSurah"],
                "ar": ar_ayahs[j]["text"],
                "en": en_ayahs[j]["text"],
                "fr": fr_ayahs[j]["text"],
                "id": id_ayahs[j]["text"]
            }
            surah["verses"].append(verse)
            
        output.append(surah)

    with open("app/src/main/assets/quran.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False)
        
    print("Successfully generated quran.json")
except Exception as e:
    print(f"Error: {e}")
