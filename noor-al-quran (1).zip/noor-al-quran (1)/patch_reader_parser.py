with open("app/src/main/java/com/example/data/repository/QuranData.kt", "r") as f:
    text = f.read()

new_code = """
    private var allAyahsCache: Map<Int, List<Ayah>>? = null

    fun initialize(context: android.content.Context) {
        if (allAyahsCache != null) return
        
        try {
            val cache = mutableMapOf<Int, List<Ayah>>()
            context.assets.open("quran.json").bufferedReader().use { reader ->
                val jsonReader = android.util.JsonReader(reader)
                jsonReader.beginArray()
                while (jsonReader.hasNext()) {
                    var surahId = 0
                    val ayahs = mutableListOf<Ayah>()
                    
                    jsonReader.beginObject()
                    while (jsonReader.hasNext()) {
                        val name = jsonReader.nextName()
                        if (name == "id") {
                            surahId = jsonReader.nextInt()
                        } else if (name == "verses") {
                            jsonReader.beginArray()
                            while (jsonReader.hasNext()) {
                                var ayahNum = 0
                                var textArabic = ""
                                val translations = mutableMapOf<String, String>()
                                
                                jsonReader.beginObject()
                                while (jsonReader.hasNext()) {
                                    val vName = jsonReader.nextName()
                                    if (vName == "id") {
                                        ayahNum = jsonReader.nextInt()
                                    } else if (vName == "ar") {
                                        textArabic = jsonReader.nextString()
                                    } else {
                                        translations[vName] = jsonReader.nextString()
                                    }
                                }
                                jsonReader.endObject()
                                
                                ayahs.add(Ayah(
                                    surahNumber = surahId,
                                    ayahNumber = ayahNum,
                                    textArabic = textArabic,
                                    translations = translations
                                ))
                            }
                            jsonReader.endArray()
                        } else {
                            jsonReader.skipValue()
                        }
                    }
                    jsonReader.endObject()
                    cache[surahId] = ayahs
                }
                jsonReader.endArray()
            }
            allAyahsCache = cache
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getAyahsForSurah(surahId: Int): List<Ayah> {
        return allAyahsCache?.get(surahId) ?: emptyList()
    }
}
"""

start_idx = text.find("    private var allAyahsCache")
if start_idx != -1:
    text = text[:start_idx] + new_code
    with open("app/src/main/java/com/example/data/repository/QuranData.kt", "w") as f:
        f.write(text)
    print("Patched parser.")
else:
    print("Could not find allAyahsCache")
