import re

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    content = f.read()

content = content.replace("import androidx.compose.runtime.Composable", "import androidx.compose.runtime.Composable\nimport androidx.compose.runtime.produceState\nimport androidx.compose.runtime.getValue")

old_daily_ayah = """    val dailyAyah = QuranData.getAyahsForSurah(2).find { it.ayahNumber == 255 } 
        ?: QuranData.getAyahsForSurah(1).firstOrNull() 
        ?: com.example.data.model.Ayah(surahNumber = 1, ayahNumber = 1, textArabic = "Data loading error", translations = emptyMap())"""

new_daily_ayah = """    val dailyAyah by produceState<com.example.data.model.Ayah?>(initialValue = null) {
        val ayahs2 = QuranData.fetchAyahsForSurah(2)
        val ayahs1 = QuranData.fetchAyahsForSurah(1)
        value = ayahs2.find { it.ayahNumber == 255 } 
            ?: ayahs1.firstOrNull() 
            ?: com.example.data.model.Ayah(surahNumber = 1, ayahNumber = 1, textArabic = "Data loading error", translations = emptyMap())
    }
    
    if (dailyAyah == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            androidx.compose.material3.CircularProgressIndicator()
        }
        return
    }
"""
content = content.replace(old_daily_ayah, new_daily_ayah)

# Also fix dailyAyah!! or dailyAyah where it is now nullable but we return if null
content = content.replace("dailyAyah.textArabic", "dailyAyah!!.textArabic")
content = content.replace("dailyAyah.translations", "dailyAyah!!.translations")
content = content.replace("dailyAyah.surahNumber", "dailyAyah!!.surahNumber")
content = content.replace("dailyAyah.ayahNumber", "dailyAyah!!.ayahNumber")

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "w") as f:
    f.write(content)
