import urllib.request, json, os

editions = {
    "ar": "ara-quransimple",
    "am": "amh-muhammedsadiqan",
    "en": "eng-abdelhaleem",
    "ur": "urd-abulaalamaududi",
    "id": "ind-indonesianislam",
    "fr": "fra-islamicfoundati",
    "es": "spa-abdulqadermouhe",
    "tr": "tur-abdulbakigolpin",
    "bn": "ben-abubakrzakaria",
    "hi": "hin-maulanaazizulha",
    "ru": "rus-abuadel",
    "de": "deu-aburidamuhammad"
}

surahs = {i: {"id": i, "verses": []} for i in range(1, 115)}
for i in range(1, 115):
    # Just initialize the verses array structure later
    pass

base_url = "https://cdn.jsdelivr.net/gh/fawazahmed0/quran-api@1/editions/{}.json"

all_data = {}

for lang, ed in editions.items():
    print(f"Downloading {lang} ({ed})...")
    url = base_url.format(ed)
    req = urllib.request.urlopen(url)
    data = json.loads(req.read().decode("utf-8"))["quran"]
    all_data[lang] = data

# Build the consolidated JSON
for i in range(1, 115):
    surahs[i]["verses"] = []

# Assuming all have exactly 6236 verses and are in the same order
# The api is ordered 1:1, 1:2 ... 114:6
for i in range(6236):
    verse_ar = all_data["ar"][i]
    chapter = verse_ar["chapter"]
    verse_id = verse_ar["verse"]
    
    verse_obj = {
        "id": verse_id,
        "ar": verse_ar["text"]
    }
    
    for lang in editions.keys():
        if lang != "ar":
            verse_obj[lang] = all_data[lang][i]["text"]
            
    surahs[chapter]["verses"].append(verse_obj)

final_json = list(surahs.values())

with open("app/src/main/assets/quran.json", "w", encoding="utf-8") as f:
    json.dump(final_json, f, ensure_ascii=False, separators=(',', ':'))

print("Saved app/src/main/assets/quran.json")
