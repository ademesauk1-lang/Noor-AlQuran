package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.data.model.DarkModeOption
import com.example.ui.screens.MainContainerScreen
import com.example.ui.state.QuranViewModel
import com.example.ui.theme.QuranAppTheme

class MainActivity : ComponentActivity() {

  private val viewModel: QuranViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    handleIntent(intent)
    
    setContent {
      val uiState by viewModel.uiState.collectAsState()
      val systemInDark = isSystemInDarkTheme()
      val isDark = when (uiState.darkModeOption) {
        DarkModeOption.DARK -> true
        DarkModeOption.LIGHT -> false
        DarkModeOption.SYSTEM -> systemInDark
      }

      QuranAppTheme(darkTheme = isDark) {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = MaterialTheme.colorScheme.background
        ) {
          MainContainerScreen(viewModel = viewModel)
        }
      }
    }
  }

  override fun onNewIntent(intent: android.content.Intent) {
    super.onNewIntent(intent)
    handleIntent(intent)
  }

  private fun handleIntent(intent: android.content.Intent?) {
    val targetTab = intent?.getStringExtra("OPEN_TAB")
    if (targetTab == "INSPIRATION") {
      viewModel.selectTab(com.example.data.model.AppTab.INSPIRATION)
    }
  }
}

