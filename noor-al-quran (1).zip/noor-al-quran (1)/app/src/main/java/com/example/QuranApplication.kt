package com.example

import android.app.Application
import com.revenuecat.purchases.LogLevel
import com.revenuecat.purchases.Purchases
import com.revenuecat.purchases.PurchasesConfiguration

class QuranApplication : Application() {
    override fun onCreate() {
        super.onCreate()

        // Enable debug logging for RevenueCat in development
        Purchases.logLevel = LogLevel.DEBUG

        // Configure RevenueCat only if a valid public Google API key is supplied
        val apiKey = "" // Replace with actual RevenueCat API Key when configured
        if (apiKey.isNotBlank() && apiKey.startsWith("goog_") && !apiKey.contains("your_revenuecat_api_key")) {
            try {
                Purchases.configure(
                    PurchasesConfiguration.Builder(
                        context = this,
                        apiKey = apiKey
                    ).build()
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
