package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Islamic Emerald & Gold Palette
val EmeraldPrimaryLight = Color(0xFF0F523B)
val EmeraldSecondaryLight = Color(0xFF1B8A6B)
val GoldAccentLight = Color(0xFFC89000)
val BackgroundLight = Color(0xFFFBF8F3)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF2ECE1)
val OnPrimaryLight = Color(0xFFFFFFFF)

val EmeraldPrimaryDark = Color(0xFF34C796)
val EmeraldSecondaryDark = Color(0xFF26A69A)
val GoldAccentDark = Color(0xFFFFC107)
val BackgroundDark = Color(0xFF0B1713)
val SurfaceDark = Color(0xFF14241E)
val SurfaceVariantDark = Color(0xFF1D332B)
val OnPrimaryDark = Color(0xFF003825)

val QuranParchmentBg = Color(0xFFFFFDF5)
val QuranBorderGold = Color(0xFFE5C07B)
val QuranTextDark = Color(0xFF1A1A1A)
val AyahHighlightColor = Color(0x22D4AF37)

