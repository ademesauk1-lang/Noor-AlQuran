package com.example.ui.state

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.media.MediaPlayer
import androidx.lifecycle.AndroidViewModel

import io.github.jan.supabase.auth.status.SessionStatus
import com.example.data.api.SupabaseClient
import com.example.data.model.UserProfile
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.auth.auth

import androidx.lifecycle.viewModelScope
import com.example.data.model.AppTab
import com.example.data.model.Ayah
import com.example.data.model.DarkModeOption
import com.example.data.model.LastReadPosition
import com.example.data.model.Qari
import com.example.data.model.SubscriptionPlan
import com.example.data.model.Surah
import com.example.data.model.TranslationLanguage
import com.example.data.repository.QuranData
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class RepeatMode(val label: String, val playerRepeatMode: Int = 0, val shuffleModeEnabled: Boolean = false) {
    REPEAT_OFF("Repeat Off", 0, false),
    REPEAT_ONE("Repeat One", 1, false),
    REPEAT_ALL("Repeat All", 2, false),
    SHUFFLE("Shuffle", 0, true)
}

data class QuranUiState(
    val currentTab: AppTab = AppTab.HOME,
    val isDataLoading: Boolean = true,
    val selectedSurahId: Int = 1,
    val selectedAyahNumber: Int = 1,
    val searchQuery: String = "",
    val reciterSearchQuery: String = "",
    val filterType: String = "ALL", // "ALL", "MECCAN", "MEDINAN"
    val bookmarkedAyahs: Set<String> = emptySet(), // "surahId:ayahNumber"
    val lastRead: LastReadPosition = LastReadPosition(1, "Al-Fatiha", "الفاتحة", 1, System.currentTimeMillis()),
    val translationLanguage: TranslationLanguage = TranslationLanguage.ENGLISH,
    val arabicFontSizeSp: Float = 28f,
    val darkModeOption: DarkModeOption = DarkModeOption.SYSTEM,
    val notificationsEnabled: Boolean = true,
    val dailyAyahReminders: Boolean = true,
    val audioDownloadAlerts: Boolean = true,
    val isPremiumUser: Boolean = false,
    val selectedSubscriptionPlan: SubscriptionPlan = SubscriptionPlan.ANNUAL,
    val aiExplanation: String? = null,
    val isAiLoading: Boolean = false,
    val showAiExplanation: Boolean = false,
    
    // Audio Player state
    val isPlaying: Boolean = false,
    val audioSurahId: Int = 1,
    val audioAyahNumber: Int = 1,
    val selectedQari: Qari = QuranData.qariList[0],
    val audioProgress: Float = 0f,
    val audioDurationSeconds: Int = 30,
    val audioCurrentSeconds: Int = 0,
    val playbackSpeed: Float = 1.0f,
    val isLoopingSurah: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.REPEAT_OFF,
    val backgroundSound: com.example.data.model.BackgroundSound = com.example.data.model.BackgroundSound.NONE,
    val showAudioMiniPlayer: Boolean = false,
    val downloadedAudios: Set<String> = emptySet(),
    val isAudioDownloading: Boolean = false,
    val audioDownloadProgress: Int = 0,
    val isOnline: Boolean = true,
    val offlineNotice: String? = null,
    val userMessage: String? = null,
    val isUserSignedIn: Boolean = false,
    val currentUserEmail: String? = null,
    val isSyncing: Boolean = false,
    val syncStatusMessage: String? = null,
    val lastSyncTimeFormatted: String? = null
)

class QuranViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs: SharedPreferences = application.getSharedPreferences("quran_prefs", Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(QuranUiState())
    val uiState: StateFlow<QuranUiState> = _uiState.asStateFlow()

    private var mediaPlayer: MediaPlayer? = null
    private var bgMediaPlayer: MediaPlayer? = null
    private val audioRepository = com.example.data.repository.AudioRepository(application)
    private val networkMonitor = com.example.util.NetworkMonitor(application)
    private var progressJob: Job? = null
    private val syncRepository = com.example.data.repository.SupabaseSyncRepository()

    init {
        QuranData.initialize(application)

        viewModelScope.launch {
            _uiState.update { it.copy(isOnline = networkMonitor.isCurrentlyOnline()) }
            networkMonitor.isOnline.collect { online ->
                _uiState.update { it.copy(isOnline = online) }
            }
        }

        viewModelScope.launch {
            audioRepository.allDownloadedAudio.collect { list ->
                val set = list.map { it.id }.toSet()
                _uiState.update { it.copy(downloadedAudios = set) }
            }
        }
        viewModelScope.launch {
            SupabaseClient.client.auth.sessionStatus.collect { status ->
                when (status) {
                    is SessionStatus.Authenticated -> {
                        val email = status.session.user?.email
                        val userId = status.session.user?.id
                        _uiState.update { it.copy(isUserSignedIn = true, currentUserEmail = email) }
                        if (userId != null) {
                            try {
                                val profile = SupabaseClient.client.postgrest["profiles"]
                                    .select { filter { eq("id", userId) } }
                                    .decodeSingleOrNull<UserProfile>()
                                    
                                if (profile != null) {
                                    // Sync reading progress
                                    if (profile.last_read_surah != null && profile.last_read_ayah != null) {
                                        val newLastRead = _uiState.value.lastRead.copy(
                                            surahId = profile.last_read_surah,
                                            ayahNumber = profile.last_read_ayah
                                        )
                                        _uiState.update { it.copy(lastRead = newLastRead) }
                                    }
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    }
                    is SessionStatus.NotAuthenticated -> {
                        _uiState.update { it.copy(isUserSignedIn = false, currentUserEmail = null) }
                    }
                    else -> {}
                }
            }
        }

        loadPreferences()
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            QuranData.initialize(getApplication())
            _uiState.update { it.copy(isDataLoading = false) }
        }
    }

    private fun loadPreferences() {
        val hasSeenWelcome = prefs.getBoolean("has_seen_welcome", false)
        val savedBookmarks = prefs.getStringSet("bookmarks", emptySet()) ?: emptySet()
        val lastSurahId = prefs.getInt("last_surah_id", 1)
        val lastAyahNum = prefs.getInt("last_ayah_num", 1)
        val fontSize = prefs.getFloat("font_size", 28f)
        val langOrdinal = prefs.getInt("translation_lang", 0)
        val darkOrdinal = prefs.getInt("dark_mode_option", 0)
        val qariId = prefs.getString("selected_qari_id", "mishary") ?: "mishary"
        val notifEnabled = prefs.getBoolean("notif_enabled", true)
        val dailyReminders = prefs.getBoolean("daily_reminders", true)
        val audioAlerts = prefs.getBoolean("audio_alerts", true)
        val isPremium = prefs.getBoolean("is_premium_user", false)
        val bgSoundName = prefs.getString("background_sound", "NONE") ?: "NONE"
        val bgSound = com.example.data.model.BackgroundSound.valueOf(bgSoundName)

        val surah = QuranData.surahs.find { it.id == lastSurahId } ?: QuranData.surahs[0]
        val lang = TranslationLanguage.entries.getOrElse(langOrdinal) { TranslationLanguage.ENGLISH }
        val darkMode = DarkModeOption.entries.getOrElse(darkOrdinal) { DarkModeOption.SYSTEM }
        val savedQari = QuranData.qariList.find { it.id == qariId } ?: QuranData.qariList[0]

        val initialTab = if (hasSeenWelcome) AppTab.HOME else AppTab.WELCOME
        _uiState.update {
            it.copy(
                currentTab = initialTab,
                bookmarkedAyahs = savedBookmarks,
                selectedSurahId = lastSurahId,
                selectedAyahNumber = lastAyahNum,
                arabicFontSizeSp = fontSize,
                translationLanguage = lang,
                darkModeOption = darkMode,
                selectedQari = savedQari,
                notificationsEnabled = notifEnabled,
                dailyAyahReminders = dailyReminders,
                audioDownloadAlerts = audioAlerts,
                isPremiumUser = isPremium,
                backgroundSound = bgSound,
                lastRead = LastReadPosition(surah.id, surah.nameEnglish, surah.nameArabic, lastAyahNum, System.currentTimeMillis())
            )
        }
    }

    fun selectSubscriptionPlan(plan: SubscriptionPlan) {
        _uiState.update { it.copy(selectedSubscriptionPlan = plan) }
    }

    fun unlockPremium() {
        prefs.edit().putBoolean("is_premium_user", true).apply()
        _uiState.update { it.copy(isPremiumUser = true) }
    }


        private val tabStack = mutableListOf<AppTab>()

    fun navigateToPremium() {
        tabStack.add(_uiState.value.currentTab)
        _uiState.update { it.copy(currentTab = AppTab.PREMIUM) }
    }
    
    fun navigateToAbout() {
        tabStack.add(_uiState.value.currentTab)
        _uiState.update { it.copy(currentTab = AppTab.ABOUT) }
    }

    fun navigateToAuth() {
        tabStack.add(_uiState.value.currentTab)
        _uiState.update { it.copy(currentTab = AppTab.AUTH) }
    }

    fun navigateToPrivacyPolicy() {
        tabStack.add(_uiState.value.currentTab)
        _uiState.update { it.copy(currentTab = AppTab.PRIVACY_POLICY) }
    }

    fun navigateToTermsOfService() {
        tabStack.add(_uiState.value.currentTab)
        _uiState.update { it.copy(currentTab = AppTab.TERMS_OF_SERVICE) }
    }

    fun completeWelcome() {
        prefs.edit().putBoolean("has_seen_welcome", true).apply()
        _uiState.update { it.copy(currentTab = AppTab.HOME) }
    }

    fun popBackStack() {
        if (tabStack.isNotEmpty()) {
            val previous = tabStack.removeAt(tabStack.lastIndex)
            _uiState.update { it.copy(currentTab = previous) }
        } else {
            _uiState.update { it.copy(currentTab = AppTab.HOME) }
        }
    }

    fun selectTab(tab: AppTab) {
        if (_uiState.value.currentTab != tab) {
            if (_uiState.value.currentTab != AppTab.WELCOME) {
                if (tabStack.isEmpty() || tabStack.last() != _uiState.value.currentTab) {
                    tabStack.add(_uiState.value.currentTab)
                }
            }
            _uiState.update { it.copy(currentTab = tab) }
        }
    }

    fun openReaderForSurah(surahId: Int, ayahNumber: Int = 1) {
        val surah = QuranData.surahs.find { it.id == surahId } ?: return
        val newLastRead = LastReadPosition(
            surahId = surah.id,
            surahNameEnglish = surah.nameEnglish,
            surahNameArabic = surah.nameArabic,
            ayahNumber = ayahNumber,
            timestampMs = System.currentTimeMillis()
        )
        
        prefs.edit()
            .putInt("last_surah_id", surahId)
            .putInt("last_ayah_num", ayahNumber)
            .apply()

        _uiState.update {
            it.copy(
                selectedSurahId = surahId,
                audioSurahId = if (!it.isPlaying) surahId else it.audioSurahId,
                selectedAyahNumber = ayahNumber,
                lastRead = newLastRead,
                currentTab = AppTab.READER
            )
        }
    }

    fun updateLastReadAyah(ayahNumber: Int) {
        val current = _uiState.value.lastRead
        if (current.ayahNumber == ayahNumber) return
        val newLastRead = current.copy(ayahNumber = ayahNumber, timestampMs = System.currentTimeMillis())
        prefs.edit().putInt("last_ayah_num", ayahNumber).apply()
        _uiState.update { it.copy(lastRead = newLastRead) }
        
        // Sync to Supabase
        viewModelScope.launch {
            val session = SupabaseClient.client.auth.currentSessionOrNull()
            val userId = session?.user?.id ?: return@launch
            try {
                val profile = UserProfile(id = userId, last_read_surah = newLastRead.surahId, last_read_ayah = newLastRead.ayahNumber)
                SupabaseClient.client.postgrest["profiles"].upsert(profile)
            } catch(e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setFilterType(type: String) {
        _uiState.update { it.copy(filterType = type) }
    }

    fun toggleBookmark(surahId: Int, ayahNumber: Int) {
        val key = "$surahId:$ayahNumber"
        val current = _uiState.value.bookmarkedAyahs.toMutableSet()
        if (current.contains(key)) {
            current.remove(key)
        } else {
            current.add(key)
        }
        
        prefs.edit().putStringSet("bookmarks", current).apply()
        _uiState.update { it.copy(bookmarkedAyahs = current) }
    }

    fun isBookmarked(surahId: Int, ayahNumber: Int): Boolean {
        return _uiState.value.bookmarkedAyahs.contains("$surahId:$ayahNumber")
    }

    fun updateFontSize(newSizeSp: Float) {
        prefs.edit().putFloat("font_size", newSizeSp).apply()
        _uiState.update { it.copy(arabicFontSizeSp = newSizeSp) }
    }

    fun setTranslationLanguage(lang: TranslationLanguage) {
        prefs.edit().putInt("translation_lang", lang.ordinal).apply()
        _uiState.update { it.copy(translationLanguage = lang) }
    }

    fun clearUserMessage() {
        _uiState.update { it.copy(userMessage = null) }
    }

    fun playAudio(surahId: Int, ayahNumber: Int = 1) {
        val selectedQari = _uiState.value.selectedQari
        if (!selectedQari.isSurahRecorded(surahId)) {
            val surah = QuranData.surahs.find { it.id == surahId } ?: QuranData.surahs[0]
            _uiState.update {
                it.copy(
                    isPlaying = false,
                    showAudioMiniPlayer = true,
                    audioSurahId = surahId,
                    userMessage = "Surah ${surah.nameEnglish} has not been recorded by Sheikh ${selectedQari.name}."
                )
            }
            return
        }
        val baseUrl = selectedQari.baseAudioUrl.trimEnd('/')
        val remoteUrl = "$baseUrl/${String.format(java.util.Locale.US, "%03d.mp3", surahId)}"
        playAudioSource(surahId, ayahNumber, remoteUrl, isFallbackAttempted = false)
    }

    private fun playAudioSource(surahId: Int, ayahNumber: Int, remoteUrl: String, isFallbackAttempted: Boolean) {
        val qari = _uiState.value.selectedQari

        viewModelScope.launch {
            val downloaded = audioRepository.getDownloadedAudio(surahId, qari.id)
            val audioSource: String?
            var isOfflineCached = false

            if (downloaded != null && java.io.File(downloaded.localFilePath).exists()) {
                audioSource = downloaded.localFilePath
                isOfflineCached = true
            } else if (_uiState.value.isOnline) {
                audioSource = remoteUrl
                // Automatically cache via WorkManager / Room for offline playback next time
                audioRepository.triggerBackgroundCache(surahId, qari.id, remoteUrl)
            } else {
                audioSource = null
            }

            if (audioSource == null) {
                val notice = "Audio for Surah $surahId is not downloaded for offline listening. Connect to internet to stream or download."
                _uiState.update {
                    it.copy(
                        isPlaying = false,
                        showAudioMiniPlayer = true,
                        audioSurahId = surahId,
                        audioAyahNumber = ayahNumber,
                        offlineNotice = notice,
                        userMessage = "Failed to load audio. Please check your internet connection."
                    )
                }
                return@launch
            }

            val cacheNotice = if (isOfflineCached) "Playing Surah $surahId from offline cache ⚡" else null

            progressJob?.cancel()
            try {
                mediaPlayer?.stop()
                mediaPlayer?.release()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            mediaPlayer = null

            _uiState.update {
                it.copy(
                    audioSurahId = surahId,
                    audioAyahNumber = ayahNumber,
                    isPlaying = false,
                    showAudioMiniPlayer = true,
                    audioProgress = 0f,
                    audioCurrentSeconds = 0,
                    offlineNotice = cacheNotice
                )
            }

            try {
                android.util.Log.d("AudioPlayer", "Attempting to play URL: $audioSource")
                val newPlayer = MediaPlayer().apply {
                    setDataSource(audioSource)
                    isLooping = (_uiState.value.repeatMode == RepeatMode.REPEAT_ONE)
                    setOnPreparedListener { mp ->
                        try {
                            mp.start()
                            val currentBg = _uiState.value.backgroundSound
                            if (currentBg.audioUrl != null && bgMediaPlayer == null && _uiState.value.isOnline) {
                                try {
                                    bgMediaPlayer = MediaPlayer().apply {
                                        setDataSource(currentBg.audioUrl)
                                        isLooping = true
                                        setVolume(0.3f, 0.3f)
                                        setOnPreparedListener { bgMp -> bgMp.start() }
                                        prepareAsync()
                                    }
                                } catch (e: Exception) { e.printStackTrace() }
                            } else if (bgMediaPlayer != null && bgMediaPlayer?.isPlaying == false) {
                                bgMediaPlayer?.start()
                            }
                            applyPlaybackSpeed(_uiState.value.playbackSpeed)
                            val durMs = mp.duration
                            if (durMs in 1..5000) {
                                android.util.Log.w("QuranViewModel", "Invalid audio duration detected ($durMs ms). Server returned HTML 404 page.")
                                try {
                                    mp.stop()
                                    mp.reset()
                                    mp.release()
                                } catch (e: Exception) { e.printStackTrace() }
                                mediaPlayer = null

                                if (!isFallbackAttempted) {
                                    val fallbackUrl = com.example.util.QuranUtils.buildFallbackAudioUrl(qari, surahId)
                                    _uiState.update {
                                        it.copy(
                                            isPlaying = false,
                                            userMessage = "Retrying audio for Sheikh ${qari.name}..."
                                        )
                                    }
                                    playAudioSource(surahId, ayahNumber, fallbackUrl, isFallbackAttempted = true)
                                } else {
                                    _uiState.update {
                                        it.copy(
                                            isPlaying = false,
                                            userMessage = "Audio stream for Sheikh ${qari.name} is currently unavailable. Please select another reciter."
                                        )
                                    }
                                }
                                return@setOnPreparedListener
                            }

                            val durSecs = if (durMs > 0) durMs / 1000 else 180
                            _uiState.update {
                                it.copy(
                                    audioDurationSeconds = durSecs,
                                    isPlaying = true
                                )
                            }
                            startProgressTimer()
                        } catch (e: Exception) {
                            android.util.Log.e("QuranViewModel", "Error starting player after prepare: ${e.message}")
                            _uiState.update {
                                it.copy(
                                    isPlaying = false,
                                    userMessage = "Error starting audio playback."
                                )
                            }
                        }
                    }
                    setOnCompletionListener {
                        _uiState.update { it.copy(isPlaying = false) }
                        if (_uiState.value.audioDurationSeconds in 1..5) {
                            return@setOnCompletionListener
                        }
                        when (_uiState.value.repeatMode) {
                            RepeatMode.REPEAT_ONE -> playAudio(surahId, 1)
                            RepeatMode.SHUFFLE -> playAudio((1..114).random(), 1)
                            RepeatMode.REPEAT_ALL -> nextAudioTrack()
                            RepeatMode.REPEAT_OFF -> {
                                if (surahId < 114) {
                                    nextAudioTrack()
                                } else {
                                    _uiState.update { it.copy(isPlaying = false, audioProgress = 0f) }
                                }
                            }
                        }
                    }
                    setOnErrorListener { _, what, extra ->
                        android.util.Log.e("QuranViewModel", "MediaPlayer error: what=$what extra=$extra source=$audioSource")
                        android.util.Log.e("ExoPlayerError", "Code: $what, Message: Playback error $what (extra=$extra), Cause: Source URL $audioSource")
                        try {
                            reset()
                            release()
                        } catch (e: Exception) {
                            android.util.Log.e("ExoPlayerError", "Error releasing player: ${e.message}")
                        }
                        mediaPlayer = null
                        
                        if (!isFallbackAttempted) {
                            android.util.Log.d("QuranViewModel", "Primary server failed. Trying backup audio stream for Sheikh ${qari.name}...")
                            val fallbackUrl = com.example.util.QuranUtils.buildFallbackAudioUrl(qari, surahId)
                            _uiState.update {
                                it.copy(
                                    isPlaying = false,
                                    userMessage = "Retrying audio stream for Sheikh ${qari.name}..."
                                )
                            }
                            playAudioSource(surahId, ayahNumber, fallbackUrl, isFallbackAttempted = true)
                        } else {
                            _uiState.update {
                                it.copy(
                                    isPlaying = false,
                                    userMessage = "Audio stream for Sheikh ${qari.name} is currently unavailable. Please select another reciter or check connection."
                                )
                            }
                        }
                        true
                    }
                    try {
                        prepareAsync()
                    } catch (e: Exception) {
                        android.util.Log.e("QuranViewModel", "prepareAsync error: ${e.message}")
                        if (!isFallbackAttempted) {
                            val fallbackUrl = com.example.util.QuranUtils.buildFallbackAudioUrl(qari, surahId)
                            playAudioSource(surahId, ayahNumber, fallbackUrl, isFallbackAttempted = true)
                        }
                    }
                }
                mediaPlayer = newPlayer
            } catch (e: Exception) {
                e.printStackTrace()
                _uiState.update {
                    it.copy(
                        isPlaying = false,
                        userMessage = "Failed to load audio for Sheikh ${qari.name}. Please check your connection."
                    )
                }
            }
        }
    }

    fun togglePlayPause() {
        val player = mediaPlayer
        if (player != null) {
            try {
                if (player.isPlaying) {
                    player.pause()
                    _uiState.update { it.copy(isPlaying = false) }
                    progressJob?.cancel()
                } else {
                    player.start()
                    applyPlaybackSpeed(_uiState.value.playbackSpeed)
                    _uiState.update { it.copy(isPlaying = true) }
                    startProgressTimer()
                }
            } catch (e: Exception) {
                playAudio(_uiState.value.audioSurahId, 1)
            }
        } else {
            playAudio(_uiState.value.audioSurahId, 1)
        }
    }

    fun nextAudioTrack() {
        val currentSurahId = _uiState.value.audioSurahId
        val nextSurahId = if (_uiState.value.repeatMode == RepeatMode.SHUFFLE) {
            (1..114).random()
        } else {
            if (currentSurahId < 114) currentSurahId + 1 else 1
        }
        playAudio(nextSurahId, 1)
    }

    fun previousAudioTrack() {
        val currentSurahId = _uiState.value.audioSurahId
        val prevSurahId = if (_uiState.value.repeatMode == RepeatMode.SHUFFLE) {
            (1..114).random()
        } else {
            if (currentSurahId > 1) currentSurahId - 1 else 114
        }
        playAudio(prevSurahId, 1)
    }

    fun selectQari(qari: Qari) {
        prefs.edit().putString("selected_qari_id", qari.id).apply()
        val currentSurahId = _uiState.value.audioSurahId
        _uiState.update { it.copy(selectedQari = qari) }
        playAudio(currentSurahId, 1)
    }

    fun updateReciterSearchQuery(query: String) {
        _uiState.update { it.copy(reciterSearchQuery = query) }
    }

    fun setDarkModeOption(option: DarkModeOption) {
        prefs.edit().putInt("dark_mode_option", option.ordinal).apply()
        _uiState.update { it.copy(darkModeOption = option) }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("notif_enabled", enabled).apply()
        _uiState.update { it.copy(notificationsEnabled = enabled) }
    }

    fun setDailyAyahReminders(enabled: Boolean) {
        prefs.edit().putBoolean("daily_reminders", enabled).apply()
        _uiState.update { it.copy(dailyAyahReminders = enabled) }
    }

    fun setAudioDownloadAlerts(enabled: Boolean) {
        prefs.edit().putBoolean("audio_alerts", enabled).apply()
        _uiState.update { it.copy(audioDownloadAlerts = enabled) }
    }

    fun togglePlaybackSpeed() {
        val nextSpeed = when (_uiState.value.playbackSpeed) {
            1.0f -> 1.25f
            1.25f -> 1.5f
            1.5f -> 2.0f
            2.0f -> 0.75f
            0.75f -> 1.0f
            else -> 1.0f
        }
        _uiState.update { it.copy(playbackSpeed = nextSpeed) }
        applyPlaybackSpeed(nextSpeed)
    }

    private fun applyPlaybackSpeed(speed: Float) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            try {
                mediaPlayer?.let { player ->
                    if (player.isPlaying) {
                        player.playbackParams = player.playbackParams.setSpeed(speed)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun seekAudio(progress: Float) {
        val player = mediaPlayer
        val totalSecs = _uiState.value.audioDurationSeconds
        val currentSecs = (progress * totalSecs).toInt()
        if (player != null && totalSecs > 0) {
            try {
                val seekMs = (progress * player.duration).toInt()
                player.seekTo(seekMs)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        _uiState.update { it.copy(audioProgress = progress, audioCurrentSeconds = currentSecs) }
    }


    fun setBackgroundSound(sound: com.example.data.model.BackgroundSound) {
        _uiState.update { it.copy(backgroundSound = sound) }
        prefs.edit().putString("background_sound", sound.name).apply()
        
        bgMediaPlayer?.release()
        bgMediaPlayer = null
        
        if (sound.audioUrl != null && _uiState.value.isPlaying) {
            bgMediaPlayer = MediaPlayer().apply {
                setDataSource(sound.audioUrl)
                isLooping = true
                setVolume(0.3f, 0.3f)
                setOnPreparedListener { mp ->
                    mp.start()
                }
                prepareAsync()
            }
        }
    }
    fun toggleLoopSurah() {
        val nextMode = when (_uiState.value.repeatMode) {
            RepeatMode.REPEAT_OFF -> RepeatMode.REPEAT_ONE
            RepeatMode.REPEAT_ONE -> RepeatMode.REPEAT_ALL
            RepeatMode.REPEAT_ALL -> RepeatMode.SHUFFLE
            RepeatMode.SHUFFLE -> RepeatMode.REPEAT_OFF
        }
        setRepeatMode(nextMode)
    }

    fun setRepeatMode(mode: RepeatMode) {
        _uiState.update { it.copy(repeatMode = mode, isLoopingSurah = (mode == RepeatMode.REPEAT_ONE)) }
        try {
            mediaPlayer?.isLooping = (mode == RepeatMode.REPEAT_ONE)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        _uiState.update { it.copy(playbackSpeed = speed) }
        applyPlaybackSpeed(speed)
    }

    suspend fun getDailyVerse(langId: String): com.example.data.model.Ayah {
        // Curated inspirational verses (SurahId to AyahNum)
        val inspirationalVerses = listOf(
            Pair(2, 255), // Ayat-ul-Kursi
            Pair(2, 286), // Last verse of Baqarah
            Pair(3, 139), // Do not weaken or grieve
            Pair(24, 35), // Allah is the Light of the heavens
            Pair(39, 53), // Do not despair of the mercy of Allah
            Pair(59, 22), // He is Allah, other than whom there is no deity
            Pair(67, 1),  // Blessed is He in whose hand is dominion
            Pair(94, 5),  // For indeed, with hardship comes ease
            Pair(112, 1)  // Say He is Allah One
        )
        // Pick verse based on current day of year
        val dayOfYear = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
        val pair = inspirationalVerses[dayOfYear % inspirationalVerses.size]
        
        val ayahs = QuranData.fetchAyahsForSurah(pair.first, langId)
        val ayah = ayahs.find { it.ayahNumber == pair.second } 
            ?: ayahs.firstOrNull { it.textArabic.trim().isNotBlank() && !it.textArabic.trim().equals("بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ") }
            ?: com.example.data.model.Ayah(surahNumber = 1, ayahNumber = 1, textArabic = "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ", translations = mapOf("en" to "In the name of God, The Most Gracious, The Most Merciful"))

        // Format Arabic text to remove Bismillah if present
        val cleanArabic = com.example.util.QuranUtils.formatAyahText(ayah.surahNumber, ayah.ayahNumber, ayah.textArabic)
        return ayah.copy(textArabic = cleanArabic)
    }

    private fun startProgressTimer() {
        progressJob?.cancel()
        progressJob = viewModelScope.launch {
            while (_uiState.value.isPlaying) {
                delay(500)
                val player = mediaPlayer
                if (player != null) {
                    try {
                        if (player.isPlaying) {
                            val currentMs = player.currentPosition
                            val durationMs = player.duration
                            if (durationMs > 0) {
                                val currentSecs = currentMs / 1000
                                val durSecs = durationMs / 1000
                                val progress = currentMs.toFloat() / durationMs.toFloat()
                                _uiState.update {
                                    it.copy(
                                        audioCurrentSeconds = currentSecs,
                                        audioDurationSeconds = durSecs,
                                        audioProgress = progress.coerceIn(0f, 1f)
                                    )
                                }
                            }
                        }
                    } catch (e: Exception) {
                        break
                    }
                }
            }
        }
    }
    
    fun closeAiExplanation() {
        _uiState.update { it.copy(showAiExplanation = false, aiExplanation = null) }
    }
    
    fun explainAyah(surahId: Int, ayahNum: Int) {
        val surah = com.example.data.repository.QuranData.surahs.find { it.id == surahId } ?: return
        
        if (!_uiState.value.isOnline) {
            _uiState.update {
                it.copy(
                    showAiExplanation = true,
                    isAiLoading = false,
                    aiExplanation = "AI Tafsir requires an active internet connection. Please connect to Wi-Fi or mobile data."
                )
            }
            return
        }

        val prompt = "Please explain the meaning of Surah ${surah.nameEnglish} (Surah ${surahId}), Ayah ${ayahNum} from the Quran. Please provide a clear and insightful tafsir (exegesis) suitable for a general reader."
        
        _uiState.update { it.copy(showAiExplanation = true, isAiLoading = true, aiExplanation = null) }
        
        viewModelScope.launch {
            try {
                val apiKey = com.example.BuildConfig.GEMINI_API_KEY
                val request = com.example.data.GenerateContentRequest(
                    contents = listOf(com.example.data.Content(
                        parts = listOf(com.example.data.Part(text = prompt))
                    )),
                    generationConfig = com.example.data.GenerationConfig(
                        thinkingConfig = com.example.data.ThinkingConfig(thinkingLevel = "HIGH")
                    )
                )
                
                val response = com.example.data.GeminiClient.service.generateContent(apiKey, request)
                val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "No explanation available."
                
                _uiState.update { it.copy(isAiLoading = false, aiExplanation = text) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isAiLoading = false, aiExplanation = "Failed to load explanation: ${e.message}") }
            }
        }
    }

    fun downloadAudio(surahId: Int, qariId: String) {
        if (_uiState.value.isAudioDownloading) return
        if (!_uiState.value.isOnline) {
            _uiState.update { it.copy(offlineNotice = "Internet connection required to download Surah audio.") }
            return
        }
        
        _uiState.update { it.copy(isAudioDownloading = true, audioDownloadProgress = 0) }
        viewModelScope.launch {
            val qari = com.example.data.repository.QuranData.qariList.find { it.id == qariId } ?: _uiState.value.selectedQari
            val audioUrl = com.example.util.QuranUtils.buildAudioUrl(qari, surahId)
            
            val success = audioRepository.downloadAudio(surahId, qariId, audioUrl) { progress ->
                _uiState.update { it.copy(audioDownloadProgress = progress) }
            }
            
            _uiState.update {
                it.copy(
                    isAudioDownloading = false,
                    offlineNotice = if (success) "Surah $surahId audio downloaded successfully for offline listening!" else "Download failed. Please check connection and try again."
                )
            }
        }
    }

    fun removeDownloadedAudio(surahId: Int, qariId: String) {
        viewModelScope.launch {
            audioRepository.removeDownloadedAudio(surahId, qariId)
            _uiState.update { it.copy(offlineNotice = "Surah $surahId downloaded audio removed.") }
        }
    }

    fun dismissOfflineNotice() {
        _uiState.update { it.copy(offlineNotice = null) }
    }

    fun triggerCloudBackup() {
        if (_uiState.value.isSyncing) return
        _uiState.update { it.copy(isSyncing = true, syncStatusMessage = "Syncing with Supabase Cloud...") }
        viewModelScope.launch {
            val lastReadPage = _uiState.value.lastRead.surahId
            val bookmarkPageList = _uiState.value.bookmarkedAyahs.mapNotNull {
                it.split(":").firstOrNull()?.toIntOrNull()
            }.distinct()

            val result = syncRepository.backupData(lastReadPage, bookmarkPageList)
            val timeStr = java.text.SimpleDateFormat("MMM dd, HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            result.fold(
                onSuccess = { msg ->
                    _uiState.update {
                        it.copy(
                            isSyncing = false,
                            syncStatusMessage = msg,
                            lastSyncTimeFormatted = timeStr
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isSyncing = false,
                            syncStatusMessage = "Backup warning: ${err.localizedMessage ?: "Sync completed"}",
                            lastSyncTimeFormatted = timeStr
                        )
                    }
                }
            )
        }
    }

    fun restoreFromCloudBackup() {
        if (_uiState.value.isSyncing) return
        _uiState.update { it.copy(isSyncing = true, syncStatusMessage = "Restoring data from Supabase...") }
        viewModelScope.launch {
            val result = syncRepository.restoreData()
            val timeStr = java.text.SimpleDateFormat("MMM dd, HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            result.fold(
                onSuccess = { (lastPage, bookmarks) ->
                    if (lastPage in 1..114) {
                        openReaderForSurah(lastPage)
                    }
                    val newBookmarkSet = bookmarks.map { "$it:1" }.toSet()
                    if (newBookmarkSet.isNotEmpty()) {
                        _uiState.update { it.copy(bookmarkedAyahs = newBookmarkSet) }
                        prefs.edit().putStringSet("bookmarks", newBookmarkSet).apply()
                    }
                    _uiState.update {
                        it.copy(
                            isSyncing = false,
                            syncStatusMessage = "Data restored successfully! (Page $lastPage, ${bookmarks.size} Bookmarks)",
                            lastSyncTimeFormatted = timeStr
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isSyncing = false,
                            syncStatusMessage = "No active cloud backup found or restore issue: ${err.localizedMessage}",
                            lastSyncTimeFormatted = timeStr
                        )
                    }
                }
            )
        }
    }

    fun setupDailyNotifications(context: Context, enabled: Boolean) {
        setDailyAyahReminders(enabled)
        if (enabled) {
            com.example.util.DailyInspirationWorker.scheduleDailyNotification(context)
        } else {
            com.example.util.DailyInspirationWorker.cancelDailyNotification(context)
        }
    }

    fun signOut() {
        viewModelScope.launch {
            try {
                SupabaseClient.client.auth.signOut()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            _uiState.update { it.copy(isUserSignedIn = false, currentUserEmail = null) }
        }
    }

    override fun onCleared() {
        super.onCleared()
        mediaPlayer?.release()
        mediaPlayer = null
        bgMediaPlayer?.release()
        bgMediaPlayer = null
        progressJob?.cancel()
    }
}