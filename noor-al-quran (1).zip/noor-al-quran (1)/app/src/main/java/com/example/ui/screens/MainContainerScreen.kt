package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.AppTab
import com.example.data.repository.QuranData
import com.example.ui.state.QuranViewModel
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.GoldAccentLight
































































@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainContainerScreen(
viewModel: QuranViewModel
) {
val uiState by viewModel.uiState.collectAsState()
val context = androidx.compose.ui.platform.LocalContext.current

androidx.activity.compose.BackHandler(enabled = uiState.currentTab != AppTab.HOME) {
    viewModel.popBackStack()
}

androidx.compose.runtime.LaunchedEffect(uiState.userMessage) {
    uiState.userMessage?.let { msg ->
        android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()
        viewModel.clearUserMessage()
    }
}

if (uiState.isDataLoading) {
androidx.compose.foundation.layout.Box(modifier = androidx.compose.ui.Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
androidx.compose.material3.CircularProgressIndicator()
}
return
}
Scaffold(
topBar = {
if (uiState.currentTab in listOf(AppTab.HOME, AppTab.SURAHS, AppTab.JUZ, AppTab.RECITERS, AppTab.PROFILE)) {
TopAppBar(
title = {
Row(
verticalAlignment = Alignment.CenterVertically,
horizontalArrangement = Arrangement.spacedBy(8.dp)
) {
Text(
text = "القرآن الكريم",
fontFamily = AmiriFontFamily,
fontSize = 22.sp,
fontWeight = FontWeight.Bold,
color = MaterialTheme.colorScheme.primary,
maxLines = 1,
overflow = TextOverflow.Ellipsis,
softWrap = false
)
Text(
text = "Noor Al-Quran",
style = MaterialTheme.typography.titleMedium,
fontWeight = FontWeight.Bold,
maxLines = 1,
overflow = TextOverflow.Ellipsis,
softWrap = false
)
}
},
actions = {
IconButton(
onClick = { viewModel.navigateToPremium() },
modifier = Modifier.testTag("top_bar_premium_button")
) {
Icon(
imageVector = Icons.Default.AutoAwesome,
contentDescription = "Unlock Premium",
tint = if (uiState.isPremiumUser) GoldAccentLight else MaterialTheme.colorScheme.primary
)
}
IconButton(
onClick = { viewModel.selectTab(AppTab.MUSHAF) },
modifier = Modifier.testTag("top_bar_mushaf_button")
) {
Icon(
imageVector = Icons.AutoMirrored.Filled.MenuBook,
contentDescription = "Full Mushaf 604",
tint = if (uiState.currentTab == AppTab.MUSHAF) MaterialTheme.colorScheme.primary
else MaterialTheme.colorScheme.onSurfaceVariant
)
}
IconButton(
onClick = { viewModel.selectTab(AppTab.RECITERS) },
modifier = Modifier.testTag("top_bar_reciters_button")
) {
Icon(
imageVector = Icons.Default.RecordVoiceOver,
contentDescription = "Reciters",
tint = if (uiState.currentTab == AppTab.RECITERS) MaterialTheme.colorScheme.primary
else MaterialTheme.colorScheme.onSurfaceVariant
)
}
},
colors = TopAppBarDefaults.topAppBarColors(
containerColor = MaterialTheme.colorScheme.surface
)
)
}
},
bottomBar = {
Column {
// Persistent Mini Audio Player
if (uiState.showAudioMiniPlayer && uiState.currentTab != AppTab.PLAYER) {
val currentSurah = QuranData.surahs.find { it.id == uiState.audioSurahId } ?: QuranData.surahs[0]
Card(
modifier = Modifier
.fillMaxWidth()
.padding(horizontal = 12.dp, vertical = 4.dp)
.clickable { viewModel.selectTab(AppTab.PLAYER) }
.testTag("mini_audio_player_bar"),
colors = CardDefaults.cardColors(
containerColor = MaterialTheme.colorScheme.primaryContainer
),
shape = RoundedCornerShape(14.dp),
elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
) {
Row(
modifier = Modifier
.fillMaxWidth()
.padding(horizontal = 14.dp, vertical = 10.dp),
verticalAlignment = Alignment.CenterVertically,
horizontalArrangement = Arrangement.SpaceBetween
) {
Row(
verticalAlignment = Alignment.CenterVertically,
modifier = Modifier.weight(1f)
) {
val miniQariModel: Any = uiState.selectedQari.imageResId
?: if (uiState.selectedQari.photoUrl.isNotBlank()) uiState.selectedQari.photoUrl
else "https://images.unsplash.com/photo-1542838132-92c53300491e?w=300&q=80"
AsyncImage(
model = miniQariModel,
contentDescription = uiState.selectedQari.name,
contentScale = androidx.compose.ui.layout.ContentScale.Crop,
modifier = Modifier
.size(36.dp)
.clip(CircleShape)
)
Spacer(modifier = Modifier.width(12.dp))
Column {
Text(
text = "Surah ${currentSurah.nameEnglish} • ${currentSurah.nameArabic}",
style = MaterialTheme.typography.titleMedium,
fontWeight = FontWeight.Bold,
maxLines = 1,
overflow = TextOverflow.Ellipsis,
softWrap = false
)
Text(
text = "${uiState.selectedQari.name} • ${if (uiState.isPlaying) "Playing" else "Paused"}",
style = MaterialTheme.typography.bodyMedium,
color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
maxLines = 1,
overflow = TextOverflow.Ellipsis,
softWrap = false
)
}
}
IconButton(onClick = { viewModel.togglePlayPause() }) {
Icon(
imageVector = if (uiState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
contentDescription = "Play/Pause Audio",
tint = MaterialTheme.colorScheme.primary
)
}
}
}
}
// Bottom Navigation Bar
if (uiState.currentTab in listOf(AppTab.HOME, AppTab.SURAHS, AppTab.JUZ, AppTab.MUSHAF, AppTab.RECITERS, AppTab.PROFILE, AppTab.PLAYER, AppTab.READER, AppTab.INSPIRATION)) {
NavigationBar(
containerColor = MaterialTheme.colorScheme.surface,
modifier = Modifier.testTag("bottom_nav_bar")
) {
val items = listOf(
TabNavItem(AppTab.HOME, Icons.Default.Home, "home_tab"),
TabNavItem(AppTab.READER, Icons.AutoMirrored.Filled.List, "reader_tab"),
TabNavItem(AppTab.INSPIRATION, Icons.Filled.Star, "inspiration_tab"),
TabNavItem(AppTab.PLAYER, Icons.Default.Headphones, "player_tab"),
TabNavItem(AppTab.PROFILE, Icons.Default.Person, "profile_tab")
)
items.forEach { item ->
val selected = uiState.currentTab == item.tab
NavigationBarItem(
selected = selected,
onClick = { viewModel.selectTab(item.tab) },
icon = {
Icon(
imageVector = item.icon,
contentDescription = item.tab.label
)
},
label = {
Text(
text = item.tab.label,
fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
fontSize = 10.sp,
maxLines = 1,
overflow = TextOverflow.Ellipsis
)
},
alwaysShowLabel = true,
colors = NavigationBarItemDefaults.colors(
selectedIconColor = MaterialTheme.colorScheme.primary,
selectedTextColor = MaterialTheme.colorScheme.primary,
unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
indicatorColor = MaterialTheme.colorScheme.primaryContainer
),
modifier = Modifier.testTag(item.testTag)
)
}
}
}
}
}
) { paddingValues ->
Box(
modifier = Modifier
.fillMaxSize()
.padding(paddingValues)
) {
Column(modifier = Modifier.fillMaxSize()) {
if (!uiState.isOnline) {
Surface(
modifier = Modifier.fillMaxWidth(),
color = MaterialTheme.colorScheme.errorContainer,
contentColor = MaterialTheme.colorScheme.onErrorContainer
) {
Row(
modifier = Modifier
.fillMaxWidth()
.padding(horizontal = 16.dp, vertical = 6.dp),
verticalAlignment = Alignment.CenterVertically,
horizontalArrangement = Arrangement.spacedBy(8.dp)
) {
Icon(
imageVector = Icons.Default.WifiOff,
contentDescription = "Offline Mode",
modifier = Modifier.size(18.dp)
)
Text(
text = "Offline Mode — Local Quran text & downloaded audio active",
style = MaterialTheme.typography.labelMedium,
fontWeight = FontWeight.SemiBold,
modifier = Modifier.weight(1f)
)
}
}
}

if (uiState.offlineNotice != null) {
Surface(
modifier = Modifier.fillMaxWidth(),
color = MaterialTheme.colorScheme.primaryContainer,
contentColor = MaterialTheme.colorScheme.onPrimaryContainer
) {
Row(
modifier = Modifier
.fillMaxWidth()
.padding(horizontal = 16.dp, vertical = 8.dp),
verticalAlignment = Alignment.CenterVertically,
horizontalArrangement = Arrangement.SpaceBetween
) {
Text(
text = uiState.offlineNotice ?: "",
style = MaterialTheme.typography.bodySmall,
modifier = Modifier.weight(1f)
)
IconButton(
onClick = { viewModel.dismissOfflineNotice() },
modifier = Modifier.size(24.dp)
) {
Icon(
imageVector = Icons.Default.Close,
contentDescription = "Dismiss",
modifier = Modifier.size(16.dp)
)
}
}
}
}

Box(modifier = Modifier.weight(1f)) {
when (uiState.currentTab) {
AppTab.WELCOME -> WelcomeScreen(onGetStarted = { viewModel.completeWelcome() })
AppTab.HOME -> HomeScreen(
uiState = uiState,
onOpenReader = { surahId, ayahNum -> viewModel.openReaderForSurah(surahId, ayahNum) },
onPlayAudio = { surahId, ayahNum -> viewModel.playAudio(surahId, ayahNum) },
onToggleBookmark = { surahId, ayahNum -> viewModel.toggleBookmark(surahId, ayahNum) },
onSelectTab = { viewModel.selectTab(it) },
onSelectQari = { viewModel.selectQari(it) }
)
AppTab.SURAHS -> SurahListScreen(
uiState = uiState,
onSearchQueryChange = { viewModel.updateSearchQuery(it) },
onFilterChange = { viewModel.setFilterType(it) },
onOpenReader = { viewModel.openReaderForSurah(it) },
onPlayAudio = { viewModel.playAudio(it) }
)
AppTab.JUZ -> JuzScreen(
onOpenReaderForJuz = { surahId, ayahNum -> viewModel.openReaderForSurah(surahId, ayahNum) }
)
AppTab.MUSHAF -> MushafScreen(
onNavigateBack = { viewModel.selectTab(AppTab.HOME) }
)
AppTab.READER -> ReaderScreen(
uiState = uiState,
onSelectSurah = { viewModel.openReaderForSurah(it) },
onPlayAudio = { surahId, ayahNum -> viewModel.playAudio(surahId, ayahNum) },
onToggleBookmark = { surahId, ayahNum -> viewModel.toggleBookmark(surahId, ayahNum) },
onUpdateFontSize = { viewModel.updateFontSize(it) },
onSelectTranslation = { viewModel.setTranslationLanguage(it) },
onUpdateLastReadAyah = { viewModel.updateLastReadAyah(it) },
onExplainAyah = { surahId, ayahNum -> viewModel.explainAyah(surahId, ayahNum) },
onCloseExplanation = { viewModel.closeAiExplanation() }
)
AppTab.PLAYER -> PlayerScreen(
uiState = uiState,
onTogglePlayPause = { viewModel.togglePlayPause() },
onNextTrack = { viewModel.nextAudioTrack() },
onPreviousTrack = { viewModel.previousAudioTrack() },
onSeekAudio = { viewModel.seekAudio(it) },
onSelectQari = { viewModel.selectQari(it) },
onToggleLoop = { viewModel.toggleLoopSurah() },
onToggleSpeed = { viewModel.togglePlaybackSpeed() },
onSelectRepeatMode = { viewModel.setRepeatMode(it) },
onSelectPlaybackSpeed = { viewModel.setPlaybackSpeed(it) },
onSelectBackgroundSound = { viewModel.setBackgroundSound(it) },
onDownloadAudio = { surahId, qariId -> viewModel.downloadAudio(surahId, qariId) },
onNavigateToPremium = { viewModel.selectTab(AppTab.PREMIUM) },
onPlaySurah = { surahId -> viewModel.playAudio(surahId, 1) }
)
AppTab.RECITERS -> RecitersScreen(
uiState = uiState,
onSearchQueryChange = { viewModel.updateReciterSearchQuery(it) },
onSelectQari = { viewModel.selectQari(it) },
onPlayAudioPreview = { qari ->
viewModel.selectQari(qari)
viewModel.playAudio(1, 1)
}
)
AppTab.PROFILE -> ProfileScreen(
uiState = uiState,
onUpdateFontSize = { viewModel.updateFontSize(it) },
onSelectDarkMode = { viewModel.setDarkModeOption(it) },
onSelectTranslationLanguage = { viewModel.setTranslationLanguage(it) },
onToggleNotifications = { viewModel.setNotificationsEnabled(it) },
onToggleDailyAyah = { viewModel.setDailyAyahReminders(it) },
onToggleAudioAlerts = { viewModel.setAudioDownloadAlerts(it) },
onSignOut = { viewModel.signOut() },
onTriggerBackup = { viewModel.triggerCloudBackup() },
onRestoreBackup = { viewModel.restoreFromCloudBackup() },
onNavigateToTab = { if (it == AppTab.PREMIUM) viewModel.navigateToPremium() else if (it == AppTab.AUTH) viewModel.navigateToAuth() else if (it == AppTab.ABOUT) viewModel.navigateToAbout() else if (it == AppTab.PRIVACY_POLICY) viewModel.navigateToPrivacyPolicy() else if (it == AppTab.TERMS_OF_SERVICE) viewModel.navigateToTermsOfService() else viewModel.selectTab(it) }
)
AppTab.PREMIUM -> PremiumUnlockScreen(
uiState = uiState,
onSelectPlan = { viewModel.selectSubscriptionPlan(it) },
onStartTrial = { viewModel.unlockPremium() },
onDismiss = { viewModel.popBackStack() }
)
AppTab.AUTH_CALLBACK -> AuthCallbackScreen(
onNavigateHome = { viewModel.popBackStack() }
)
AppTab.AUTH -> AuthScreen(onNavigateHome = { viewModel.popBackStack() })
AppTab.ABOUT -> AboutScreen(
    onNavigateBack = { viewModel.popBackStack() },
    onNavigateToPrivacyPolicy = { viewModel.navigateToPrivacyPolicy() },
    onNavigateToTermsOfService = { viewModel.navigateToTermsOfService() }
)
AppTab.PRIVACY_POLICY -> PrivacyPolicyScreen(onNavigateBack = { viewModel.popBackStack() })
AppTab.TERMS_OF_SERVICE -> TermsOfServiceScreen(onNavigateBack = { viewModel.popBackStack() })
AppTab.THEME_LAB -> ThemeLabScreen(
uiState = uiState,
onSelectDarkMode = { viewModel.setDarkModeOption(it) },
onNavigateHome = { viewModel.selectTab(AppTab.HOME) }
)
AppTab.INSPIRATION -> InspirationScreen(
onPlayAudio = { surahId, ayahNum -> viewModel.playAudio(surahId, ayahNum) }
)
}
}
}
}
}
}

private data class TabNavItem(
val tab: AppTab,
val icon: ImageVector,
val testTag: String
)