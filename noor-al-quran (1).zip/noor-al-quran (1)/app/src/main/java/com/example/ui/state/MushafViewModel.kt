package com.example.ui.state

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Ayah
import com.example.data.model.Surah
import com.example.data.repository.MushafPageContent
import com.example.data.repository.MushafPageInfo
import com.example.data.repository.MushafPageMapper
import com.example.data.repository.QuranData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MushafUiState(
    val currentPageNumber: Int = 1,
    val totalPages: Int = 604,
    val fontSizeSp: Float = 26f,
    val keepScreenOn: Boolean = true,
    val currentPageContent: MushafPageContent? = null,
    val pageInfo: MushafPageInfo = MushafPageMapper.getPageInfo(1),
    val isLoadingPage: Boolean = false,
    val isJumpDialogOpen: Boolean = false,
    val bookmarkedPages: Set<Int> = emptySet(),
    val cachedPages: Map<Int, MushafPageContent> = emptyMap()
)

class MushafViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs: SharedPreferences = application.getSharedPreferences("mushaf_prefs", Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(MushafUiState())
    val uiState: StateFlow<MushafUiState> = _uiState.asStateFlow()

    init {
        // Restore last read page and bookmarks
        val savedPage = prefs.getInt("mushaf_last_read_page", 1).coerceIn(1, 604)
        val savedFontSize = prefs.getFloat("mushaf_font_size", 26f)
        val savedBookmarks = prefs.getStringSet("mushaf_bookmarks", emptySet())
            ?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()

        _uiState.update {
            it.copy(
                currentPageNumber = savedPage,
                fontSizeSp = savedFontSize,
                bookmarkedPages = savedBookmarks,
                pageInfo = MushafPageMapper.getPageInfo(savedPage)
            )
        }

        loadPage(savedPage)
    }

    fun loadPage(pageNumber: Int) {
        val page = pageNumber.coerceIn(1, 604)
        
        // Save last read page in SharedPreferences
        prefs.edit().putInt("mushaf_last_read_page", page).apply()

        val info = MushafPageMapper.getPageInfo(page)
        _uiState.update { 
            it.copy(
                currentPageNumber = page,
                pageInfo = info,
                isLoadingPage = !it.cachedPages.containsKey(page)
            ) 
        }

        // Fetch page content
        viewModelScope.launch {
            if (_uiState.value.cachedPages.containsKey(page)) {
                val content = _uiState.value.cachedPages[page]
                _uiState.update { it.copy(currentPageContent = content, isLoadingPage = false) }
            } else {
                val content = MushafPageMapper.loadPageContent(page)
                _uiState.update { state ->
                    val newCache = state.cachedPages.toMutableMap()
                    newCache[page] = content
                    state.copy(
                        currentPageContent = content,
                        isLoadingPage = false,
                        cachedPages = newCache
                    )
                }
            }

            // Pre-fetch adjacent pages (page-1 and page+1) for instantaneous swiping
            preloadPage(page - 1)
            preloadPage(page + 1)
        }
    }

    private fun preloadPage(pageNumber: Int) {
        if (pageNumber in 1..604 && !_uiState.value.cachedPages.containsKey(pageNumber)) {
            viewModelScope.launch {
                try {
                    val content = MushafPageMapper.loadPageContent(pageNumber)
                    _uiState.update { state ->
                        val newCache = state.cachedPages.toMutableMap()
                        newCache[pageNumber] = content
                        state.copy(cachedPages = newCache)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun updateFontSize(newSize: Float) {
        val clampedSize = newSize.coerceIn(18f, 42f)
        prefs.edit().putFloat("mushaf_font_size", clampedSize).apply()
        _uiState.update { it.copy(fontSizeSp = clampedSize) }
    }

    fun toggleBookmarkPage(pageNumber: Int = _uiState.value.currentPageNumber) {
        val currentBookmarks = _uiState.value.bookmarkedPages.toMutableSet()
        if (currentBookmarks.contains(pageNumber)) {
            currentBookmarks.remove(pageNumber)
        } else {
            currentBookmarks.add(pageNumber)
        }
        prefs.edit().putStringSet("mushaf_bookmarks", currentBookmarks.map { it.toString() }.toSet()).apply()
        _uiState.update { it.copy(bookmarkedPages = currentBookmarks) }
    }

    fun jumpToSurah(surahId: Int) {
        val page = MushafPageMapper.getPageForSurah(surahId)
        loadPage(page)
    }

    fun jumpToJuz(juzNumber: Int) {
        val page = MushafPageMapper.getPageForJuz(juzNumber)
        loadPage(page)
    }

    fun setJumpDialogOpen(isOpen: Boolean) {
        _uiState.update { it.copy(isJumpDialogOpen = isOpen) }
    }
}
