import re

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "r") as f:
    content = f.read()

imports = """
import io.github.jan.supabase.auth.status.SessionStatus
import com.example.data.api.SupabaseClient
import com.example.data.model.UserProfile
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.auth.auth
"""

content = content.replace("import androidx.lifecycle.AndroidViewModel", "import androidx.lifecycle.AndroidViewModel\n" + imports)

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "w") as f:
    f.write(content)

