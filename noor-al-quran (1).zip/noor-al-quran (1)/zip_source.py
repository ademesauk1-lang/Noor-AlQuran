import zipfile
import os

files_to_zip = ["build.gradle.kts", "settings.gradle.kts", "gradle.properties"]
dirs_to_zip = ["app/src", "gradle"]

with zipfile.ZipFile("Noor-Al-Quran-Source.zip", "w", zipfile.ZIP_DEFLATED) as zipf:
    for f in files_to_zip:
        if os.path.exists(f):
            zipf.write(f)
    for d in dirs_to_zip:
        for root, dirs, files in os.walk(d):
            for file in files:
                filepath = os.path.join(root, file)
                zipf.write(filepath)
