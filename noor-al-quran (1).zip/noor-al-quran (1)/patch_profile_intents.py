import re

with open("app/src/main/java/com/example/ui/screens/ProfileScreen.kt", "r") as f:
    content = f.read()

# Make sure LocalContext is imported
if "import androidx.compose.ui.platform.LocalContext" not in content:
    content = content.replace("import androidx.compose.ui.platform.testTag", "import androidx.compose.ui.platform.testTag\nimport androidx.compose.ui.platform.LocalContext")
if "import android.content.Intent" not in content:
    content = content.replace("import androidx.compose.foundation.background", "import androidx.compose.foundation.background\nimport android.content.Intent\nimport android.net.Uri")

# Add context variable
if "val context = LocalContext.current" not in content:
    content = content.replace("val primaryColor = MaterialTheme.colorScheme.primary", "val primaryColor = MaterialTheme.colorScheme.primary\n    val context = LocalContext.current")

old_about_section = """        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = darkItemBg),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column {
                    AboutRow(icon = Icons.Default.Info, title = "About App", description = "Version 1.0.0", textWhite = textWhite, textGray = textGray)
                    HorizontalDivider(color = darkIconBg)
                    AboutRow(icon = Icons.Default.Star, title = "Rate Us", description = "Love the app? Leave a review", textWhite = textWhite, textGray = textGray)
                    HorizontalDivider(color = darkIconBg)
                    AboutRow(icon = Icons.Default.Share, title = "Share with Friends", description = "Share the rewards", textWhite = textWhite, textGray = textGray)
                    HorizontalDivider(color = darkIconBg)
                    AboutRow(icon = Icons.AutoMirrored.Filled.Help, title = "Help & Support", description = "Contact our support team", textWhite = textWhite, textGray = textGray)
                }
            }
        }"""

new_about_section = """        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = darkItemBg),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column {
                    AboutRow(icon = Icons.Default.Info, title = "About App", description = "Version 1.0.0 by AI Studio", textWhite = textWhite, textGray = textGray, onClick = {})
                    HorizontalDivider(color = darkIconBg)
                    AboutRow(icon = Icons.Default.Share, title = "Share with Friends", description = "Share the rewards", textWhite = textWhite, textGray = textGray, onClick = {
                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                            putExtra(Intent.EXTRA_TEXT, "Read the Quran on this beautiful app! https://quran.aistudio.com")
                            type = "text/plain"
                        }
                        val shareIntent = Intent.createChooser(sendIntent, null)
                        context.startActivity(shareIntent)
                    })
                    HorizontalDivider(color = darkIconBg)
                    AboutRow(icon = Icons.AutoMirrored.Filled.Help, title = "Help & Support", description = "Contact our support team", textWhite = textWhite, textGray = textGray, onClick = {
                        val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                            data = Uri.parse("mailto:")
                            putExtra(Intent.EXTRA_EMAIL, arrayOf("support@quran.aistudio.com"))
                            putExtra(Intent.EXTRA_SUBJECT, "Support Request: Quran App")
                        }
                        context.startActivity(Intent.createChooser(emailIntent, "Send Email"))
                    })
                    HorizontalDivider(color = darkIconBg)
                    AboutRow(icon = Icons.Default.Info, title = "Privacy Policy & Terms", description = "Read our terms of service", textWhite = textWhite, textGray = textGray, onClick = {
                        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://quran.aistudio.com/privacy"))
                        context.startActivity(browserIntent)
                    })
                }
            }
        }"""

content = content.replace(old_about_section, new_about_section)

# Update AboutRow signature
old_about_row_sig = """@Composable
private fun AboutRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    textWhite: Color,
    textGray: Color
) {"""

new_about_row_sig = """@Composable
private fun AboutRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    textWhite: Color,
    textGray: Color,
    onClick: () -> Unit = {}
) {"""

content = content.replace(old_about_row_sig, new_about_row_sig)
content = content.replace(".clickable { /* action */ }", ".clickable { onClick() }")

with open("app/src/main/java/com/example/ui/screens/ProfileScreen.kt", "w") as f:
    f.write(content)

