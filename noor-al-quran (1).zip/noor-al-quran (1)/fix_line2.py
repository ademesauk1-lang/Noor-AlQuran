with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    lines = f.readlines()

new_lines = []
for line in lines:
    if "import " in line:
        parts = line.split("import ")
        for p in parts:
            if p.strip():
                new_lines.append("import " + p.strip() + "\n")
    else:
        new_lines.append(line)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.writelines(new_lines)

print("Line 2 fixed")
