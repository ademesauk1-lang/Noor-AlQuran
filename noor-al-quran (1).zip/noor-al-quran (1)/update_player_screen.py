with open("app/src/main/java/com/example/ui/screens/PlayerScreen.kt", "r") as f:
    content = f.read()

# Make sure imports include CheckCircle and RadioButtonUnchecked
if "import androidx.compose.material.icons.filled.CheckCircle" not in content:
    content = content.replace(
        "import androidx.compose.material.icons.filled.Check",
        "import androidx.compose.material.icons.filled.Check\nimport androidx.compose.material.icons.filled.CheckCircle\nimport androidx.compose.material.icons.filled.RadioButtonUnchecked"
    )

# Replace bottom sheet qari image & artwork image
old_sheet_async = """                                    AsyncImage(
                                        model = qari.imageResId ?: qari.photoUrl,
                                        contentDescription = qari.name,
                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(androidx.compose.foundation.shape.CircleShape)
                                            .background(darkIconBg)
                                            .then(if (isLocked) Modifier.alpha(0.5f) else Modifier)
                                    )"""

new_sheet_async = """                                    val qariImageModel: Any = qari.imageResId 
                                        ?: if (qari.photoUrl.isNotBlank()) qari.photoUrl 
                                        else "https://images.unsplash.com/photo-1542838132-92c53300491e?w=300&q=80"
                                    AsyncImage(
                                        model = qariImageModel,
                                        contentDescription = qari.name,
                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(androidx.compose.foundation.shape.CircleShape)
                                            .background(darkIconBg)
                                            .then(if (isLocked) Modifier.alpha(0.5f) else Modifier)
                                    )"""

if old_sheet_async in content:
    content = content.replace(old_sheet_async, new_sheet_async)

old_artwork = """                if (uiState.selectedQari.imageResId != null || uiState.selectedQari.photoUrl.isNotEmpty()) {
                    AsyncImage(
                        model = uiState.selectedQari.imageResId ?: uiState.selectedQari.photoUrl,
                        contentDescription = "Reciter Photo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(80.dp)
                        )
                    }
                }"""

new_artwork = """                val selectedQariModel: Any = uiState.selectedQari.imageResId
                    ?: if (uiState.selectedQari.photoUrl.isNotBlank()) uiState.selectedQari.photoUrl
                    else "https://images.unsplash.com/photo-1542838132-92c53300491e?w=300&q=80"
                AsyncImage(
                    model = selectedQariModel,
                    contentDescription = "Reciter Photo",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )"""

if old_artwork in content:
    content = content.replace(old_artwork, new_artwork)

with open("app/src/main/java/com/example/ui/screens/PlayerScreen.kt", "w") as f:
    f.write(content)
print("PlayerScreen.kt updated successfully")
