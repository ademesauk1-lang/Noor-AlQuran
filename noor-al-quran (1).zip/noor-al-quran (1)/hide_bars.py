import re

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    content = f.read()

# TopAppBar
content = content.replace("        topBar = {\n            TopAppBar(", "        topBar = {\n            if (uiState.currentTab in listOf(AppTab.HOME, AppTab.SURAHS, AppTab.JUZ, AppTab.RECITERS, AppTab.PROFILE)) {\n            TopAppBar(")
content = content.replace("                )\n            )\n        },", "                )\n            )\n            }\n        },")

# NavigationBar
content = content.replace("                // Bottom Navigation Bar\n                NavigationBar(", "                // Bottom Navigation Bar\n                if (uiState.currentTab in listOf(AppTab.HOME, AppTab.SURAHS, AppTab.JUZ, AppTab.RECITERS, AppTab.PROFILE, AppTab.PLAYER, AppTab.READER)) {\n                NavigationBar(")
content = content.replace("                        }\n                    }\n                }\n            }\n        }\n    ) { innerPadding ->", "                        }\n                    }\n                }\n                }\n            }\n        }\n    ) { innerPadding ->")

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(content)
