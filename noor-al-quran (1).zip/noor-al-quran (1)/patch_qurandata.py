import re

with open("app/src/main/java/com/example/data/repository/QuranData.kt", "r") as f:
    content = f.read()

init_orig = """    fun initialize(context: android.content.Context) {}"""
init_new = """
    private var ayahDao: com.example.data.local.AyahDao? = null
    
    fun initialize(context: android.content.Context) {
        ayahDao = com.example.data.local.AppDatabase.getDatabase(context).ayahDao()
    }
"""
content = content.replace(init_orig, init_new)

fetch_orig = """    suspend fun fetchAyahsForSurah(surahId: Int, langId: String = "en"): List<Ayah> {
        val cacheKey = "$surahId-$langId"
        if (allAyahsCache.containsKey(cacheKey)) {
            return allAyahsCache[cacheKey]!!
        }

        try {
            val arabicResponse = com.example.data.api.RetrofitClient.apiService.getSurahArabic(surahId)
            val endpoint = getTranslationEndpoint(langId)
            val englishResponse = com.example.data.api.RetrofitClient.apiService.getSurahTranslation(surahId, endpoint)
            
            val ayahs = arabicResponse.data.ayahs.mapIndexed { index, arabicAyah ->
                val englishAyah = englishResponse.data.ayahs.getOrNull(index)
                val translations = if (englishAyah != null) mapOf(langId to englishAyah.text) else emptyMap()
                
                com.example.data.model.Ayah(
                    surahNumber = surahId,
                    ayahNumber = arabicAyah.numberInSurah,
                    textArabic = arabicAyah.text,
                    tafsir = null,
                    translations = translations
                )
            }
            allAyahsCache[cacheKey] = ayahs
            return ayahs
        } catch (e: Exception) {
            e.printStackTrace()
            return emptyList()
        }
    }"""
fetch_new = """    suspend fun fetchAyahsForSurah(surahId: Int, langId: String = "en"): List<Ayah> {
        val cacheKey = "$surahId-$langId"
        if (allAyahsCache.containsKey(cacheKey)) {
            return allAyahsCache[cacheKey]!!
        }
        
        // Try to get from database first
        val dao = ayahDao
        if (dao != null) {
            val savedEntities = dao.getAyahsForSurah(surahId)
            if (savedEntities.isNotEmpty()) {
                val hasTranslation = savedEntities.first().translations.containsKey(langId)
                if (hasTranslation) {
                    val ayahs = savedEntities.map { entity ->
                        com.example.data.model.Ayah(
                            surahNumber = entity.surahNumber,
                            ayahNumber = entity.ayahNumber,
                            textArabic = entity.textArabic,
                            tafsir = entity.tafsir,
                            translations = entity.translations
                        )
                    }
                    allAyahsCache[cacheKey] = ayahs
                    return ayahs
                }
            }
        }

        try {
            val arabicResponse = com.example.data.api.RetrofitClient.apiService.getSurahArabic(surahId)
            val endpoint = getTranslationEndpoint(langId)
            val englishResponse = com.example.data.api.RetrofitClient.apiService.getSurahTranslation(surahId, endpoint)
            
            val ayahs = arabicResponse.data.ayahs.mapIndexed { index, arabicAyah ->
                val englishAyah = englishResponse.data.ayahs.getOrNull(index)
                val translations = if (englishAyah != null) mapOf(langId to englishAyah.text) else emptyMap()
                
                com.example.data.model.Ayah(
                    surahNumber = surahId,
                    ayahNumber = arabicAyah.numberInSurah,
                    textArabic = arabicAyah.text,
                    tafsir = null,
                    translations = translations
                )
            }
            
            // Save to database
            if (dao != null) {
                // We might need to merge translations with existing ones in DB
                val existingEntities = dao.getAyahsForSurah(surahId)
                val entitiesToInsert = ayahs.mapIndexed { index, ayah ->
                    val existing = existingEntities.find { it.ayahNumber == ayah.ayahNumber }
                    val mergedTranslations = existing?.translations?.toMutableMap() ?: mutableMapOf()
                    mergedTranslations.putAll(ayah.translations)
                    
                    com.example.data.local.AyahEntity(
                        id = "${ayah.surahNumber}_${ayah.ayahNumber}",
                        surahNumber = ayah.surahNumber,
                        ayahNumber = ayah.ayahNumber,
                        textArabic = ayah.textArabic,
                        tafsir = ayah.tafsir,
                        translations = mergedTranslations
                    )
                }
                dao.insertAyahs(entitiesToInsert)
            }
            
            allAyahsCache[cacheKey] = ayahs
            return ayahs
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback to offline data if network fails, even if wrong language
            if (dao != null) {
                val savedEntities = dao.getAyahsForSurah(surahId)
                if (savedEntities.isNotEmpty()) {
                    val ayahs = savedEntities.map { entity ->
                        com.example.data.model.Ayah(
                            surahNumber = entity.surahNumber,
                            ayahNumber = entity.ayahNumber,
                            textArabic = entity.textArabic,
                            tafsir = entity.tafsir,
                            translations = entity.translations
                        )
                    }
                    allAyahsCache[cacheKey] = ayahs
                    return ayahs
                }
            }
            return emptyList()
        }
    }"""
content = content.replace(fetch_orig, fetch_new)

with open("app/src/main/java/com/example/data/repository/QuranData.kt", "w") as f:
    f.write(content)

