import java.io.File
import org.json.JSONArray
fun main() {
    val f = File("app/src/main/assets/quran.json")
    println(f.exists())
    println(f.length())
}
