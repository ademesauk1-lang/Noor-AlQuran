with open("app/src/main/java/com/example/ui/screens/ReaderScreen.kt", "r") as f:
    text = f.read()

import re

# Replace the when statement for translation
old_when = """val activeTranslation = when (translationLang) {
                TranslationLanguage.ENGLISH -> ayah.translationEnglish
                TranslationLanguage.URDU -> ayah.translationUrdu.ifEmpty { ayah.translationEnglish }
                TranslationLanguage.INDONESIAN -> ayah.translationIndonesian.ifEmpty { ayah.translationEnglish }
            }"""

new_when = 'val activeTranslation = ayah.translations[translationLang.id] ?: ayah.translations["en"] ?: ""'

# Note: The text in the file might have different indentation. Let's use regex.

text = re.sub(r'val activeTranslation = when \(translationLang\) \{.*?\n\s*\}', new_when, text, flags=re.DOTALL)

with open("app/src/main/java/com/example/ui/screens/ReaderScreen.kt", "w") as f:
    f.write(text)
