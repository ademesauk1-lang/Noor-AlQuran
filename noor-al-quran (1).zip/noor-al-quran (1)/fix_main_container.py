with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    text = f.read()

# Remove the broken prepended lines
text = text.replace("import coil.compose.AsyncImageimport androidx.compose.foundation.shape.CircleShape", "")

# Put imports right after package com.example.ui.screens
pkg = "package com.example.ui.screens"
if pkg in text:
    idx = text.find(pkg) + len(pkg)
    text = text[:idx] + "\nimport coil.compose.AsyncImage\nimport androidx.compose.foundation.shape.CircleShape\nimport androidx.compose.ui.draw.clip" + text[idx:]

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(text)

print("MainContainerScreen fixed")
