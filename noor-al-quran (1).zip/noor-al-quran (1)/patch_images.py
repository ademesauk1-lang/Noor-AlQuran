import re

with open("app/src/main/java/com/example/ui/screens/PlayerScreen.kt", "r") as f:
    player = f.read()

player = player.replace(
    "model = qari.photoUrl,",
    "model = qari.imageResId ?: qari.photoUrl,"
)

# Only replace the one associated with size(48.dp)
# Actually, the user says "Make sure the images are styled nicely as circular or rounded avatars."
# Let's change the .clip(RoundedCornerShape(12.dp)) near AsyncImage to CircleShape
import re
player = re.sub(
    r'\.clip\(RoundedCornerShape\(12\.dp\)\)(\s*)\.background\(darkIconBg\)(\s*)\.then\(if \(isLocked\) Modifier\.alpha\(0\.5f\) else Modifier\)',
    r'.clip(androidx.compose.foundation.shape.CircleShape)\g<1>.background(darkIconBg)\g<2>.then(if (isLocked) Modifier.alpha(0.5f) else Modifier)',
    player
)

with open("app/src/main/java/com/example/ui/screens/PlayerScreen.kt", "w") as f:
    f.write(player)

with open("app/src/main/java/com/example/ui/screens/RecitersScreen.kt", "r") as f:
    reciters = f.read()

if "import coil.compose.AsyncImage" not in reciters:
    reciters = reciters.replace("import androidx.compose.ui.Modifier", "import androidx.compose.ui.Modifier\nimport coil.compose.AsyncImage")
if "import androidx.compose.ui.layout.ContentScale" not in reciters:
    reciters = reciters.replace("import androidx.compose.ui.Modifier", "import androidx.compose.ui.Modifier\nimport androidx.compose.ui.layout.ContentScale")

old_index_block = """                // Index Block
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(darkIconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${index + 1}",
                        color = textWhite,
                        fontWeight = FontWeight.Bold
                    )
                }"""

new_index_block = """                // Reciter Image
                AsyncImage(
                    model = qari.imageResId ?: qari.photoUrl,
                    contentDescription = qari.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(darkIconBg)
                )"""

reciters = reciters.replace(old_index_block, new_index_block)

with open("app/src/main/java/com/example/ui/screens/RecitersScreen.kt", "w") as f:
    f.write(reciters)

