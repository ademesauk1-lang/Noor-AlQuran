import re

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "r") as f:
    content = f.read()

target = "val showAudioMiniPlayer: Boolean = false"
replacement = "val showAudioMiniPlayer: Boolean = false,\n    val downloadedAudios: Set<String> = emptySet(),\n    val isAudioDownloading: Boolean = false,\n    val audioDownloadProgress: Int = 0"

if "downloadedAudios: Set<String>" not in content:
    content = content.replace(target, replacement)

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "w") as f:
    f.write(content)
