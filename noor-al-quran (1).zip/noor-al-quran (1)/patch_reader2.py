with open("app/src/main/java/com/example/ui/screens/ReaderScreen.kt", "r") as f:
    text = f.read()

text = text.replace('ayah.translationEnglish', 'ayah.translations[uiState.translationLanguage.id] ?: ""')

with open("app/src/main/java/com/example/ui/screens/ReaderScreen.kt", "w") as f:
    f.write(text)
