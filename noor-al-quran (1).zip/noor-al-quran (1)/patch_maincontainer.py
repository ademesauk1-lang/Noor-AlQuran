import re

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    content = f.read()

# Make sure AppTab is used for WELCOME
content = content.replace(
    "                AppTab.HOME -> HomeScreen(",
    "                AppTab.WELCOME -> WelcomeScreen(onGetStarted = { viewModel.completeWelcome() })\n                AppTab.HOME -> HomeScreen("
)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(content)
