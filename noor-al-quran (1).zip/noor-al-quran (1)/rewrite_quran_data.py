import re

with open("app/src/main/java/com/example/data/repository/QuranData.kt", "r") as f:
    content = f.read()

# Replace initialize method and getAyahsForSurah
start_idx = content.find("private var allAyahsCache: Map<Int, List<Ayah>>? = null")

if start_idx != -1:
    new_code = """
    private val allAyahsCache = mutableMapOf<Int, List<Ayah>>()

    fun initialize(context: android.content.Context) {
        // No longer loading from local JSON
    }

    suspend fun fetchAyahsForSurah(surahId: Int): List<Ayah> {
        if (allAyahsCache.containsKey(surahId)) {
            return allAyahsCache[surahId]!!
        }
        try {
            val arabicResponse = com.example.data.api.RetrofitClient.apiService.getSurahArabic(surahId)
            val englishResponse = com.example.data.api.RetrofitClient.apiService.getSurahEnglish(surahId)
            
            val ayahs = arabicResponse.data.ayahs.mapIndexed { index, arabicAyah ->
                val englishAyah = englishResponse.data.ayahs.getOrNull(index)
                val translations = if (englishAyah != null) mapOf("en" to englishAyah.text) else emptyMap()
                
                com.example.data.model.Ayah(
                    surahNumber = surahId,
                    ayahNumber = arabicAyah.numberInSurah,
                    textArabic = arabicAyah.text,
                    tafsir = null,
                    translations = translations
                )
            }
            allAyahsCache[surahId] = ayahs
            return ayahs
        } catch (e: Exception) {
            e.printStackTrace()
            return emptyList()
        }
    }
}
"""
    content = content[:start_idx] + new_code.strip()

with open("app/src/main/java/com/example/data/repository/QuranData.kt", "w") as f:
    f.write(content)
