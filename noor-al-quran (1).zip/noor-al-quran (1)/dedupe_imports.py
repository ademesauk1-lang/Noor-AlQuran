with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    text = f.read()

lines = text.split("\n")
package_line = ""
import_lines = set()
other_lines = []

for line in lines:
    l = line.strip()
    if l.startswith("package "):
        package_line = l
    elif l.startswith("import "):
        import_lines.add(l)
    else:
        other_lines.append(line)

new_content = package_line + "\n\n" + "\n".join(sorted(list(import_lines))) + "\n\n" + "\n".join(other_lines)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(new_content)

print("Deduped imports successfully")
