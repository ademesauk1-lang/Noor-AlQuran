import re

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    main_content = f.read()

main_content = main_content.replace(
    "AppTab.AUTH -> AuthScreen(onNavigateHome = { viewModel.selectTab(AppTab.HOME) })",
    "AppTab.AUTH -> AuthScreen(onNavigateHome = { viewModel.popBackStack() })"
)
main_content = main_content.replace(
    "AppTab.AUTH_CALLBACK -> AuthCallbackScreen(\n                    onNavigateHome = { viewModel.selectTab(AppTab.HOME) }\n                )",
    "AppTab.AUTH_CALLBACK -> AuthCallbackScreen(\n                    onNavigateHome = { viewModel.popBackStack() }\n                )"
)

# And in ProfileScreen we should use navigateToAuth instead of selectTab(AppTab.AUTH) and navigateToPremium instead of selectTab(AppTab.PREMIUM)
# Actually, the ProfileScreen just calls onNavigateToTab. So in MainContainerScreen we can modify:
# onNavigateToTab = { viewModel.selectTab(it) } -> if (it == AppTab.PREMIUM) viewModel.navigateToPremium() else if (it == AppTab.AUTH) viewModel.navigateToAuth() else viewModel.selectTab(it)

main_content = main_content.replace(
    "onNavigateToTab = { viewModel.selectTab(it) }",
    "onNavigateToTab = { if (it == AppTab.PREMIUM) viewModel.navigateToPremium() else if (it == AppTab.AUTH) viewModel.navigateToAuth() else viewModel.selectTab(it) }"
)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(main_content)

