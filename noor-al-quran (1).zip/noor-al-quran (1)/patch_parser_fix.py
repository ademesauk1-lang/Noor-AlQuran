with open("app/src/main/java/com/example/data/repository/QuranData.kt", "r") as f:
    text = f.read()

text = text.replace('if (vName == "id") {', 'if (vName == "verse_id") {')

with open("app/src/main/java/com/example/data/repository/QuranData.kt", "w") as f:
    f.write(text)
