import re

with open("app/src/main/java/com/example/data/repository/QuranData.kt", "r") as f:
    content = f.read()

new_qari_list = """    val qariList = listOf(
        Qari("mishary", "Mishary Rashid Alafasy", "Kuwait", "https://server8.mp3quran.net/afs", "https://images.unsplash.com/photo-1542838132-92c53300491e?w=300&q=80", "https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/", R.drawable.alafasy),
        Qari("abdulbasit", "AbdulBaset AbdulSamad", "Egypt", "https://server7.mp3quran.net/basit", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&q=80", "https://cdn.islamic.network/quran/audio-surah/128/ar.abdulbasit-murattal/", R.drawable.abdulbaset),
        Qari("maher", "Maher Al-Muaiqly", "Saudi Arabia", "https://server12.mp3quran.net/maher", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&q=80", "https://cdn.islamic.network/quran/audio-surah/128/ar.mahermuaiqly/", R.drawable.maher),
        Qari("ghamdi", "Saad Al-Ghamdi", "Saudi Arabia", "https://server7.mp3quran.net/s_gmd", "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&q=80", "https://cdn.islamic.network/quran/audio-surah/128/ar.saadghamdi/", R.drawable.ghamdi),
        Qari("sudais", "Abdul Rahman Al-Sudais", "Saudi Arabia", "https://server11.mp3quran.net/sds", "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300&q=80", "https://cdn.islamic.network/quran/audio-surah/128/ar.sudais/", R.drawable.sudais),
        Qari("shatri", "Abu Bakr Al-Shatri", "Saudi Arabia", "https://server11.mp3quran.net/shatri", "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&q=80", "https://cdn.islamic.network/quran/audio-surah/128/ar.shaatree/", R.drawable.shatri),
        Qari("shuraim", "Saud Al-Shuraim", "Saudi Arabia", "https://server7.mp3quran.net/shur", "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=300&q=80", "https://cdn.islamic.network/quran/audio-surah/128/ar.saoodshuraym/", R.drawable.shuraim),
        Qari("husary", "Mahmoud Khalil Al-Husary", "Egypt", "https://server13.mp3quran.net/husr", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&q=80", "https://cdn.islamic.network/quran/audio-surah/128/ar.husary/", R.drawable.husary),
        Qari("dosari", "Yasser Al-Dosari", "Saudi Arabia", "https://server11.mp3quran.net/yasser", "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300&q=80", "https://cdn.islamic.network/quran/audio-surah/128/ar.yasseraldossari/", R.drawable.dosari),
        Qari("rifai", "Hani Ar-Rifai", "Saudi Arabia", "https://server8.mp3quran.net/hani", "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&q=80", "https://cdn.islamic.network/quran/audio-surah/128/ar.hanrifai/", R.drawable.rifai),
        Qari("nabil_rifai", "Nabil Al-Rifai", "Saudi Arabia", "https://server9.mp3quran.net/nabil", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&q=80", "https://cdn.islamic.network/quran/audio-surah/128/ar.nabilrifai/"),
        Qari("nuaina", "Ahmad Nuaina", "Egypt", "https://server11.mp3quran.net/nuaina", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&q=80", "https://cdn.islamic.network/quran/audio-surah/128/ar.ahmedneana/"),
        Qari("jadaani", "Haitham Al-Jadaani", "Saudi Arabia", "https://server16.mp3quran.net/hth3m", "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&q=80", "https://server16.mp3quran.net/hth3m/"),
        Qari("omar_hisham", "Omar Hisham Al-Arabi", "Egypt", "https://server16.mp3quran.net/omar", "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&q=80", "https://server16.mp3quran.net/omar/"),
        Qari("yamani", "Wadi' Al-Yamani", "Yemen", "https://server6.mp3quran.net/yamani", "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300&q=80", "https://server6.mp3quran.net/yamani/"),
        Qari("ossi", "Abdur Rahman Al-Ossi", "Saudi Arabia", "https://server6.mp3quran.net/ossi", "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=300&q=80", "https://server6.mp3quran.net/ossi/"),
        Qari("mustafa_ismail", "Mustafa Ismail", "Egypt", "https://server8.mp3quran.net/mustafa", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&q=80", "https://cdn.islamic.network/quran/audio-surah/128/ar.mustafaismail/"),
        Qari("jumah", "Saud Al-Jumah", "Saudi Arabia", "https://server16.mp3quran.net/jumah", "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300&q=80", "https://server16.mp3quran.net/jumah/"),
        Qari("suqair", "Yussef Al-Suqair", "Saudi Arabia", "https://server16.mp3quran.net/suqair", "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&q=80", "https://server16.mp3quran.net/suqair/"),
        Qari("fatih", "Fatih Seferagic", "Bosnia", "https://server16.mp3quran.net/fatih", "https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=300&q=80", "https://server16.mp3quran.net/fatih/"),
        Qari("suwayid", "Abdulrahman Al-Suwayid", "Saudi Arabia", "https://server16.mp3quran.net/suwayid", "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=300&q=80", "https://server16.mp3quran.net/suwayid/"),
        Qari("salimi", "Mansour Al-Salimi", "Saudi Arabia", "https://server16.mp3quran.net/salimi", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&q=80", "https://server16.mp3quran.net/salimi/"),
        Qari("shoqai", "Yerkinbek Shoqai", "Kazakhstan", "https://server16.mp3quran.net/shoqai", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&q=80", "https://server16.mp3quran.net/shoqai/"),
        Qari("raupov", "Siratullo Raupov", "Tajikistan", "https://server16.mp3quran.net/raupov", "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&q=80", "https://server16.mp3quran.net/raupov/"),
        Qari("aminov", "Muhammadloiq Aminov", "Uzbekistan", "https://server16.mp3quran.net/aminov", "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300&q=80", "https://server16.mp3quran.net/aminov/"),
        Qari("arbi", "Arbi ash-Shishani", "Chechnya", "https://server16.mp3quran.net/arbi", "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&q=80", "https://server16.mp3quran.net/arbi/"),
        Qari("obaida", "Obaida Muafaq", "Iraq", "https://server16.mp3quran.net/obaida", "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=300&q=80", "https://server16.mp3quran.net/obaida/"),
        Qari("ayyub_asif", "Mohammad Ayyub Asif", "United Kingdom", "https://server16.mp3quran.net/ayyub", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&q=80", "https://cdn.islamic.network/quran/audio-surah/128/ar.muhammadayyoub/"),
        Qari("mossad", "Abdul Rahman Mossad", "Egypt", "https://server16.mp3quran.net/mossad", "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300&q=80", "https://server16.mp3quran.net/mossad/"),
        Qari("mahdi_shishani", "Mahdi ash-Shishani", "Chechnya", "https://server16.mp3quran.net/mahdi", "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&q=80", "https://server16.mp3quran.net/mahdi/"),
        Qari("alzain", "Alzain Mohamed Ahmed", "Sudan", "https://server9.mp3quran.net/alzain", "https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=300&q=80", "https://server9.mp3quran.net/alzain/")
    )"""

start_pos = content.find("val qariList = listOf(")
end_pos = content.find("val surahs: List<Surah>")

if start_pos != -1 and end_pos != -1:
    content = content[:start_pos] + new_qari_list + "\n    " + content[end_pos:]
    with open("app/src/main/java/com/example/data/repository/QuranData.kt", "w") as f:
        f.write(content)
    print("QuranData updated successfully")
else:
    print("Failed to find positions:", start_pos, end_pos)
