import re

with open("app/build.gradle.kts", "r") as f:
    content = f.read()

# Add serialization plugin
plugins_end = content.find("}")
if plugins_end != -1:
    new_plugins = """  id("org.jetbrains.kotlin.plugin.serialization") version "2.0.20"
}"""
    content = content[:plugins_end] + new_plugins + content[plugins_end+1:]

# Add dependencies
deps_idx = content.find("implementation(platform(libs.firebase.bom))")
if deps_idx != -1:
    supabase_deps = """
  implementation(platform("io.github.jan-tennert.supabase:bom:3.1.2"))
  implementation("io.github.jan-tennert.supabase:postgrest-kt")
  implementation("io.github.jan-tennert.supabase:gotrue-kt")
  implementation("io.github.jan-tennert.supabase:compose-auth")
  implementation("io.github.jan-tennert.supabase:compose-auth-ui")
  implementation("io.ktor:ktor-client-android:3.0.3")
  implementation("io.ktor:ktor-client-core:3.0.3")
  implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
"""
    content = content[:deps_idx] + supabase_deps + content[deps_idx:]

with open("app/build.gradle.kts", "w") as f:
    f.write(content)
