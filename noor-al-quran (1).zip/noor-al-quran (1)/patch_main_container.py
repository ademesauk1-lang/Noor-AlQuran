import re

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    content = f.read()

# Make sure AppTab is imported if it wasn't. Wait, AppTab is already used.
# Insert AppTab.ABOUT inside the when(currentTab) statement.
content = content.replace(
    "                AppTab.AUTH -> AuthScreen(onNavigateHome = { viewModel.popBackStack() })",
    "                AppTab.AUTH -> AuthScreen(onNavigateHome = { viewModel.popBackStack() })\n                AppTab.ABOUT -> AboutScreen(onNavigateBack = { viewModel.popBackStack() })"
)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(content)
