import re

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    text = f.read()

# Replace any occurrence of screensimport or Imageimport or Shapeimport with newlines
text = re.sub(r'([a-zA-Z0-9_\.\>])(import\s)', r'\1\n\2', text)
text = re.sub(r'(package\s+[a-zA-Z0-9_\.]+)', r'\1\n', text)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(text)

print("Imports split successfully")
