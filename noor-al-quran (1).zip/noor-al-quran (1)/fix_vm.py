import re

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "r") as f:
    content = f.read()

# Remove the first `fun navigateToPremium()` definition
content = content.replace("    fun navigateToPremium() {\n        selectTab(AppTab.PREMIUM)\n    }\n", "")

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "w") as f:
    f.write(content)
