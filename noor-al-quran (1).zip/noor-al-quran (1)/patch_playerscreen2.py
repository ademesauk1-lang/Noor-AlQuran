import re

with open("app/src/main/java/com/example/ui/screens/PlayerScreen.kt", "r") as f:
    content = f.read()

signature_orig = """fun PlayerScreen(
    uiState: QuranUiState,
    onTogglePlayPause: () -> Unit,
    onNextTrack: () -> Unit,
    onPreviousTrack: () -> Unit,
    onSeekAudio: (Float) -> Unit,
    onSelectQari: (Qari) -> Unit,
    onToggleLoop: () -> Unit,
    onToggleSpeed: () -> Unit,
    onSelectBackgroundSound: (com.example.data.model.BackgroundSound) -> Unit = {},
    onNavigateToPremium: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {"""

signature_new = """fun PlayerScreen(
    uiState: QuranUiState,
    onTogglePlayPause: () -> Unit,
    onNextTrack: () -> Unit,
    onPreviousTrack: () -> Unit,
    onSeekAudio: (Float) -> Unit,
    onSelectQari: (Qari) -> Unit,
    onToggleLoop: () -> Unit,
    onToggleSpeed: () -> Unit,
    onSelectBackgroundSound: (com.example.data.model.BackgroundSound) -> Unit = {},
    onDownloadAudio: (Int, String) -> Unit = { _, _ -> },
    onNavigateToPremium: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {"""
content = content.replace(signature_orig, signature_new)

button_orig = """            // Download Audio Action Button (Locked / Premium state)
            OutlinedButton(
                onClick = {
                    if (!uiState.isPremiumUser) {
                        onNavigateToPremium?.invoke()
                    } else {
                        Toast.makeText(context, "Surah ${currentSurah.nameEnglish} audio saved offline!", Toast.LENGTH_SHORT).show()
                    }
                },
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.testTag("download_audio_button")
            ) {
                if (!uiState.isPremiumUser) {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = "Locked Feature",
                        tint = GoldAccentLight,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Download Audio (Premium)",
                        color = GoldAccentLight,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "Download Audio",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Audio Saved Offline ✓",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }"""

button_new = """            // Download Audio Action Button (Locked / Premium state)
            val audioId = "${currentSurah.id}_${uiState.selectedQari.id}"
            val isDownloaded = uiState.downloadedAudios.contains(audioId)
            OutlinedButton(
                onClick = {
                    if (!uiState.isPremiumUser) {
                        onNavigateToPremium?.invoke()
                    } else if (!isDownloaded && !uiState.isAudioDownloading) {
                        onDownloadAudio(currentSurah.id, uiState.selectedQari.id)
                        Toast.makeText(context, "Downloading Surah ${currentSurah.nameEnglish}...", Toast.LENGTH_SHORT).show()
                    } else if (isDownloaded) {
                        Toast.makeText(context, "Audio already saved offline!", Toast.LENGTH_SHORT).show()
                    }
                },
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.testTag("download_audio_button")
            ) {
                if (!uiState.isPremiumUser) {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = "Locked Feature",
                        tint = GoldAccentLight,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Download Audio (Premium)",
                        color = GoldAccentLight,
                        fontWeight = FontWeight.Bold
                    )
                } else if (isDownloaded) {
                    Icon(
                        imageVector = Icons.Default.DownloadDone,
                        contentDescription = "Audio Saved",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Audio Saved Offline ✓",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                } else if (uiState.isAudioDownloading) {
                    androidx.compose.material3.CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Downloading... ${uiState.audioDownloadProgress}%",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "Download Audio",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Download Audio",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }"""
            
if "import androidx.compose.material.icons.filled.DownloadDone" not in content:
    content = content.replace("import androidx.compose.material.icons.filled.Download", "import androidx.compose.material.icons.filled.Download\nimport androidx.compose.material.icons.filled.DownloadDone")

content = content.replace(button_orig, button_new)

with open("app/src/main/java/com/example/ui/screens/PlayerScreen.kt", "w") as f:
    f.write(content)
