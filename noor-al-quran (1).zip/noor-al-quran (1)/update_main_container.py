with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    content = f.read()

if "import coil.compose.AsyncImage" not in content:
    content = "import coil.compose.AsyncImage\nimport androidx.compose.foundation.shape.CircleShape\n" + content

old_mini_icon = """                                Icon(
                                    imageVector = Icons.Default.Headphones,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )"""

new_mini_icon = """                                val miniQariModel: Any = uiState.selectedQari.imageResId
                                    ?: if (uiState.selectedQari.photoUrl.isNotBlank()) uiState.selectedQari.photoUrl
                                    else "https://images.unsplash.com/photo-1542838132-92c53300491e?w=300&q=80"
                                AsyncImage(
                                    model = miniQariModel,
                                    contentDescription = uiState.selectedQari.name,
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                )"""

if old_mini_icon in content:
    content = content.replace(old_mini_icon, new_mini_icon)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(content)
print("MainContainerScreen.kt updated successfully")
