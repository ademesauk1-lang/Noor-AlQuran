import re

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "r") as f:
    content = f.read()

content = content.replace(
    "onNavigateToTab = { if (it == AppTab.PREMIUM) viewModel.navigateToPremium() else if (it == AppTab.AUTH) viewModel.navigateToAuth() else viewModel.selectTab(it) }",
    "onNavigateToTab = { if (it == AppTab.PREMIUM) viewModel.navigateToPremium() else if (it == AppTab.AUTH) viewModel.navigateToAuth() else if (it == AppTab.ABOUT) viewModel.navigateToAbout() else viewModel.selectTab(it) }"
)

with open("app/src/main/java/com/example/ui/screens/MainContainerScreen.kt", "w") as f:
    f.write(content)
