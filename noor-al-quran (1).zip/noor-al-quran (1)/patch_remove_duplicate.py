import re

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "r") as f:
    content = f.read()

# Find the position of the last '}'
last_brace = content.rfind('}')
if last_brace != -1:
    # We want to remove everything after the first `}}` that closes the class.
    # Wait, the class ends with `onCleared() { ... } }`
    
    # Let's just use regex to find `override fun onCleared() { ... } }` and remove everything after it.
    match = re.search(r'override fun onCleared\(\) \{.*?\n    \}\n\}', content, re.DOTALL)
    if match:
        end_idx = match.end()
        content = content[:end_idx]

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "w") as f:
    f.write(content)
