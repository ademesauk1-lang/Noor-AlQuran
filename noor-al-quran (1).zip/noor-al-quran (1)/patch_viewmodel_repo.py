import re

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "r") as f:
    content = f.read()

repo_prop = "    private val audioRepository = com.example.data.repository.AudioRepository(application)\n"
content = content.replace("    private var bgMediaPlayer: MediaPlayer? = null\n", "    private var bgMediaPlayer: MediaPlayer? = null\n" + repo_prop)

init_target = "        viewModelScope.launch {\n            SupabaseClient.client.auth.sessionStatus.collect"
init_replacement = """        viewModelScope.launch {
            audioRepository.allDownloadedAudio.collect { list ->
                val set = list.map { it.id }.toSet()
                _uiState.update { it.copy(downloadedAudios = set) }
            }
        }
        viewModelScope.launch {
            SupabaseClient.client.auth.sessionStatus.collect"""
if "audioRepository.allDownloadedAudio.collect" not in content:
    content = content.replace(init_target, init_replacement)

download_fn = """
    fun downloadAudio(surahId: Int, qariId: String) {
        if (_uiState.value.isAudioDownloading) return
        
        _uiState.update { it.copy(isAudioDownloading = true, audioDownloadProgress = 0) }
        viewModelScope.launch {
            val qari = com.example.data.repository.QuranData.qariList.find { it.id == qariId } ?: return@launch
            val audioUrl = "${qari.serverUrl}${String.format("%03d", surahId)}.mp3"
            
            val success = audioRepository.downloadAudio(surahId, qariId, audioUrl) { progress ->
                _uiState.update { it.copy(audioDownloadProgress = progress) }
            }
            
            _uiState.update { it.copy(isAudioDownloading = false) }
        }
    }
"""
content = content + download_fn

play_audio_orig = "            val audioUrl = \"${_uiState.value.selectedQari.serverUrl}${String.format(\\\"%03d\\\", surahId)}.mp3\""
play_audio_new = """            var audioUrl = "${_uiState.value.selectedQari.serverUrl}${String.format("%03d", surahId)}.mp3"
            val downloadedAudio = audioRepository.getDownloadedAudio(surahId, _uiState.value.selectedQari.id)
            if (downloadedAudio != null) {
                audioUrl = downloadedAudio.localFilePath
            }"""
if "getDownloadedAudio(surahId," not in content:
    content = content.replace('            val audioUrl = "${_uiState.value.selectedQari.serverUrl}${String.format("%03d", surahId)}.mp3"', play_audio_new)

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "w") as f:
    f.write(content)
