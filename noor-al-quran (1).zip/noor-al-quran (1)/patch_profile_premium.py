import re

with open("app/src/main/java/com/example/ui/screens/ProfileScreen.kt", "r") as f:
    content = f.read()

# Make sure Lock and WorkspacePremium icons are available
if "import androidx.compose.material.icons.filled.WorkspacePremium" not in content:
    content = content.replace("import androidx.compose.material.icons.filled.Lock", "import androidx.compose.material.icons.filled.Lock\nimport androidx.compose.material.icons.filled.WorkspacePremium")

language_orig = """                        TranslationLanguage.values().forEach { lang ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onSelectTranslationLanguage(lang) }
                                    .background(if (uiState.translationLanguage == lang) primaryColor.copy(alpha = 0.2f) else Color.Transparent)
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = lang.displayName,
                                    color = if (uiState.translationLanguage == lang) textWhite else textGray,
                                    fontWeight = if (uiState.translationLanguage == lang) FontWeight.Bold else FontWeight.Normal
                                )
                                RadioButton(
                                    selected = uiState.translationLanguage == lang,
                                    onClick = { onSelectTranslationLanguage(lang) },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = primaryColor,
                                        unselectedColor = textGray
                                    )
                                )
                            }
                        }"""
                        
language_new = """                        TranslationLanguage.values().forEach { lang ->
                            val isLocked = !uiState.isPremiumUser && lang != TranslationLanguage.ENGLISH
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { 
                                        if (isLocked) {
                                            onNavigateToTab?.invoke(com.example.data.model.AppTab.PREMIUM)
                                        } else {
                                            onSelectTranslationLanguage(lang) 
                                        }
                                    }
                                    .background(if (uiState.translationLanguage == lang) primaryColor.copy(alpha = 0.2f) else Color.Transparent)
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = lang.displayName,
                                        color = if (uiState.translationLanguage == lang) textWhite else textGray,
                                        fontWeight = if (uiState.translationLanguage == lang) FontWeight.Bold else FontWeight.Normal
                                    )
                                    if (isLocked) {
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Icon(
                                            imageVector = Icons.Default.WorkspacePremium,
                                            contentDescription = "Premium Feature",
                                            tint = GoldAccentLight,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                RadioButton(
                                    selected = uiState.translationLanguage == lang,
                                    onClick = { 
                                        if (isLocked) {
                                            onNavigateToTab?.invoke(com.example.data.model.AppTab.PREMIUM)
                                        } else {
                                            onSelectTranslationLanguage(lang) 
                                        }
                                    },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = primaryColor,
                                        unselectedColor = textGray
                                    )
                                )
                            }
                        }"""

content = content.replace(language_orig, language_new)

with open("app/src/main/java/com/example/ui/screens/ProfileScreen.kt", "w") as f:
    f.write(content)

