import re

# Patch HomeScreen
with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    home_content = f.read()

home_content = home_content.replace(
    "val ayahs2 = QuranData.fetchAyahsForSurah(2)",
    "val ayahs2 = QuranData.fetchAyahsForSurah(2, uiState.translationLanguage.id)"
)
home_content = home_content.replace(
    "val ayahs1 = QuranData.fetchAyahsForSurah(1)",
    "val ayahs1 = QuranData.fetchAyahsForSurah(1, uiState.translationLanguage.id)"
)

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "w") as f:
    f.write(home_content)

# Patch ReaderScreen
with open("app/src/main/java/com/example/ui/screens/ReaderScreen.kt", "r") as f:
    reader_content = f.read()

reader_content = reader_content.replace(
    "value = QuranData.fetchAyahsForSurah(currentSurah.id)",
    "value = QuranData.fetchAyahsForSurah(currentSurah.id, uiState.translationLanguage.id)"
)
reader_content = reader_content.replace(
    "produceState<List<com.example.data.model.Ayah>>(initialValue = emptyList(), currentSurah.id)",
    "produceState<List<com.example.data.model.Ayah>>(initialValue = emptyList(), currentSurah.id, uiState.translationLanguage.id)"
)

with open("app/src/main/java/com/example/ui/screens/ReaderScreen.kt", "w") as f:
    f.write(reader_content)

