import re

with open("app/src/main/java/com/example/ui/screens/ReaderScreen.kt", "r") as f:
    content = f.read()

content = content.replace("import androidx.compose.runtime.Composable", "import androidx.compose.runtime.Composable\nimport androidx.compose.runtime.produceState\nimport androidx.compose.runtime.getValue")

old_ayahs = "    val ayahs = QuranData.getAyahsForSurah(currentSurah.id)"
new_ayahs = """    val ayahs by produceState<List<com.example.data.model.Ayah>>(initialValue = emptyList(), currentSurah.id) {
        value = QuranData.fetchAyahsForSurah(currentSurah.id)
    }
    
    if (ayahs.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            androidx.compose.material3.CircularProgressIndicator()
        }
        return
    }
"""
content = content.replace(old_ayahs, new_ayahs)

with open("app/src/main/java/com/example/ui/screens/ReaderScreen.kt", "w") as f:
    f.write(content)
