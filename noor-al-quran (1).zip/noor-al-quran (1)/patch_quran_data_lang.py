import re

with open("app/src/main/java/com/example/data/repository/QuranData.kt", "r") as f:
    content = f.read()

# Replace allAyahsCache and fetchAyahsForSurah
start_idx = content.find("private val allAyahsCache = mutableMapOf<Int, List<Ayah>>()")
if start_idx != -1:
    new_code = """
    private val allAyahsCache = mutableMapOf<String, List<Ayah>>()
    
    private fun getTranslationEndpoint(langId: String): String {
        return when (langId) {
            "en" -> "en.asad"
            "ur" -> "ur.jalandhry"
            "fr" -> "fr.hamidullah"
            "id" -> "id.indonesian"
            "tr" -> "tr.yazir"
            "am" -> "am.sadiq"
            "es" -> "es.cortes"
            "ru" -> "ru.kuliev"
            "bn" -> "bn.bengali"
            "hi" -> "hi.hindi"
            else -> "en.asad"
        }
    }

    fun initialize(context: android.content.Context) {}

    suspend fun fetchAyahsForSurah(surahId: Int, langId: String = "en"): List<Ayah> {
        val cacheKey = "$surahId-$langId"
        if (allAyahsCache.containsKey(cacheKey)) {
            return allAyahsCache[cacheKey]!!
        }
        try {
            val arabicResponse = com.example.data.api.RetrofitClient.apiService.getSurahArabic(surahId)
            val endpoint = getTranslationEndpoint(langId)
            val englishResponse = com.example.data.api.RetrofitClient.apiService.getSurahTranslation(surahId, endpoint)
            
            val ayahs = arabicResponse.data.ayahs.mapIndexed { index, arabicAyah ->
                val englishAyah = englishResponse.data.ayahs.getOrNull(index)
                val translations = if (englishAyah != null) mapOf(langId to englishAyah.text) else emptyMap()
                
                com.example.data.model.Ayah(
                    surahNumber = surahId,
                    ayahNumber = arabicAyah.numberInSurah,
                    textArabic = arabicAyah.text,
                    tafsir = null,
                    translations = translations
                )
            }
            allAyahsCache[cacheKey] = ayahs
            return ayahs
        } catch (e: Exception) {
            e.printStackTrace()
            return emptyList()
        }
    }
}
"""
    content = content[:start_idx] + new_code.strip()

with open("app/src/main/java/com/example/data/repository/QuranData.kt", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/data/api/QuranApiService.kt", "r") as f:
    api_content = f.read()

api_content = api_content.replace(
    "@GET(\"surah/{id}/en.asad\")\n    suspend fun getSurahEnglish(@Path(\"id\") surahId: Int): SurahResponse",
    "@GET(\"surah/{id}/{endpoint}\")\n    suspend fun getSurahTranslation(@Path(\"id\") surahId: Int, @Path(\"endpoint\") endpoint: String): SurahResponse"
)

with open("app/src/main/java/com/example/data/api/QuranApiService.kt", "w") as f:
    f.write(api_content)

