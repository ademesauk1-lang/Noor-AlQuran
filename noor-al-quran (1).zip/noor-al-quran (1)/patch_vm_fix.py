with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "r") as f:
    text = f.read()

text = text.replace("""    private fun loadPreferences()
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            QuranData.initialize(getApplication())
            _uiState.update { it.copy(isDataLoading = false) }
        } {""", "    private fun loadPreferences() {")

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "w") as f:
    f.write(text)
