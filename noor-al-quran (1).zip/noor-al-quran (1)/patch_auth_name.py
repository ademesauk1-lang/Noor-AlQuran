import re

with open("app/src/main/java/com/example/ui/screens/AuthScreen.kt", "r") as f:
    content = f.read()

# Make sure postgrest is imported
if "import io.github.jan.supabase.postgrest.postgrest" not in content:
    content = content.replace("import io.github.jan.supabase.auth.auth", "import io.github.jan.supabase.auth.auth\nimport io.github.jan.supabase.postgrest.postgrest\nimport com.example.data.model.UserProfile")

old_signup = """                                SupabaseClient.client.auth.signUpWith(Email) {
                                    this.email = email
                                    this.password = password
                                }"""

new_signup = """                                val res = SupabaseClient.client.auth.signUpWith(Email) {
                                    this.email = email
                                    this.password = password
                                }
                                val userId = res?.id
                                if (userId != null && name.isNotBlank()) {
                                    try {
                                        SupabaseClient.client.postgrest["profiles"].insert(UserProfile(id = userId, full_name = name))
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                }"""

content = content.replace(old_signup, new_signup)

with open("app/src/main/java/com/example/ui/screens/AuthScreen.kt", "w") as f:
    f.write(content)
