import re

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "r") as f:
    content = f.read()

# Remove the incorrectly placed downloadAudio function
content = content.replace("""}
    fun downloadAudio(surahId: Int, qariId: String) {
        if (_uiState.value.isAudioDownloading) return
        
        _uiState.update { it.copy(isAudioDownloading = true, audioDownloadProgress = 0) }
        viewModelScope.launch {
            val qari = com.example.data.repository.QuranData.qariList.find { it.id == qariId } ?: return@launch
            val audioUrl = "${qari.serverUrl}${String.format("%03d", surahId)}.mp3"
            
            val success = audioRepository.downloadAudio(surahId, qariId, audioUrl) { progress ->
                _uiState.update { it.copy(audioDownloadProgress = progress) }
            }
            
            _uiState.update { it.copy(isAudioDownloading = false) }
        }
    }""", "}")

# Add downloadAudio inside the class before onCleared
download_fn = """
    fun downloadAudio(surahId: Int, qariId: String) {
        if (_uiState.value.isAudioDownloading) return
        
        _uiState.update { it.copy(isAudioDownloading = true, audioDownloadProgress = 0) }
        viewModelScope.launch {
            val qari = com.example.data.repository.QuranData.qariList.find { it.id == qariId } ?: return@launch
            val audioUrl = "${qari.serverUrl}${String.format("%03d", surahId)}.mp3"
            
            val success = audioRepository.downloadAudio(surahId, qariId, audioUrl) { progress ->
                _uiState.update { it.copy(audioDownloadProgress = progress) }
            }
            
            _uiState.update { it.copy(isAudioDownloading = false) }
        }
    }

    override fun onCleared() {"""
content = content.replace("    override fun onCleared() {", download_fn)

# Fix playAudio to launch a coroutine to check downloaded audio
play_audio_orig = """    fun playAudio(surahId: Int, ayahNumber: Int = 1) {
            var audioUrl = "${_uiState.value.selectedQari.serverUrl}${String.format("%03d", surahId)}.mp3"
            val downloadedAudio = audioRepository.getDownloadedAudio(surahId, _uiState.value.selectedQari.id)
            if (downloadedAudio != null) {
                audioUrl = downloadedAudio.localFilePath
            }
        
        _uiState.update {
            it.copy(
                audioSurahId = surahId,
                audioAyahNumber = ayahNumber,
                audioProgress = 0f,
                audioCurrentSeconds = 0,
                isPlaying = false // Reset before playing
            )
        }
        
        mediaPlayer?.release()
        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(audioUrl)
                setOnPreparedListener { mp ->
                    mp.start()
                    val currentBg = _uiState.value.backgroundSound
                    if (currentBg.audioUrl != null && bgMediaPlayer == null) {
                        bgMediaPlayer = MediaPlayer().apply {
                            setDataSource(currentBg.audioUrl)
                            isLooping = true
                            setVolume(0.3f, 0.3f)
                            setOnPreparedListener { bgMp -> bgMp.start() }
                            prepareAsync()
                        }
                    } else if (bgMediaPlayer != null && bgMediaPlayer?.isPlaying == false) {
                        bgMediaPlayer?.start()
                    }
                    applyPlaybackSpeed(_uiState.value.playbackSpeed)
                    val durMs = mp.duration
                    val durSecs = if (durMs > 0) durMs / 1000 else 180
                    _uiState.update {
                        it.copy(
                            audioDurationSeconds = durSecs,
                            isPlaying = true
                        )
                    }
                    startProgressTimer()
                }
                setOnCompletionListener {
                    if (_uiState.value.isLoopingSurah) {
                        playAudio(surahId, 1)
                    } else {
                        nextAudioTrack()
                    }
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }"""
    
play_audio_new = """    fun playAudio(surahId: Int, ayahNumber: Int = 1) {
        viewModelScope.launch {
            var audioUrl = "${_uiState.value.selectedQari.serverUrl}${String.format("%03d", surahId)}.mp3"
            val downloadedAudio = audioRepository.getDownloadedAudio(surahId, _uiState.value.selectedQari.id)
            if (downloadedAudio != null) {
                audioUrl = downloadedAudio.localFilePath
            }
        
            _uiState.update {
                it.copy(
                    audioSurahId = surahId,
                    audioAyahNumber = ayahNumber,
                    audioProgress = 0f,
                    audioCurrentSeconds = 0,
                    isPlaying = false // Reset before playing
                )
            }
            
            mediaPlayer?.release()
            try {
                mediaPlayer = MediaPlayer().apply {
                    setDataSource(audioUrl)
                    setOnPreparedListener { mp ->
                        mp.start()
                        val currentBg = _uiState.value.backgroundSound
                        if (currentBg.audioUrl != null && bgMediaPlayer == null) {
                            bgMediaPlayer = MediaPlayer().apply {
                                setDataSource(currentBg.audioUrl)
                                isLooping = true
                                setVolume(0.3f, 0.3f)
                                setOnPreparedListener { bgMp -> bgMp.start() }
                                prepareAsync()
                            }
                        } else if (bgMediaPlayer != null && bgMediaPlayer?.isPlaying == false) {
                            bgMediaPlayer?.start()
                        }
                        applyPlaybackSpeed(_uiState.value.playbackSpeed)
                        val durMs = mp.duration
                        val durSecs = if (durMs > 0) durMs / 1000 else 180
                        _uiState.update {
                            it.copy(
                                audioDurationSeconds = durSecs,
                                isPlaying = true
                            )
                        }
                        startProgressTimer()
                    }
                    setOnCompletionListener {
                        if (_uiState.value.isLoopingSurah) {
                            playAudio(surahId, 1)
                        } else {
                            nextAudioTrack()
                        }
                    }
                    prepareAsync()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }"""
content = content.replace(play_audio_orig, play_audio_new)

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "w") as f:
    f.write(content)
