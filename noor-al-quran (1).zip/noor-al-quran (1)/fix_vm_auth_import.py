import re

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "r") as f:
    content = f.read()

if "import io.github.jan.supabase.auth.auth" not in content:
    content = content.replace("import io.github.jan.supabase.postgrest.postgrest", "import io.github.jan.supabase.postgrest.postgrest\nimport io.github.jan.supabase.auth.auth")

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "w") as f:
    f.write(content)
