import sys

new_content = """package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Help
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FontDownload
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SettingsSuggest
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DarkModeOption
import com.example.data.model.TranslationLanguage
import com.example.ui.state.QuranUiState
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.GoldAccentLight

@Composable
fun ProfileScreen(
    uiState: QuranUiState,
    onUpdateFontSize: (Float) -> Unit,
    onSelectDarkMode: (DarkModeOption) -> Unit,
    onSelectTranslationLanguage: (TranslationLanguage) -> Unit,
    onToggleNotifications: (Boolean) -> Unit,
    onToggleDailyAyah: (Boolean) -> Unit,
    onToggleAudioAlerts: (Boolean) -> Unit,
    onNavigateToTab: ((com.example.data.model.AppTab) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val darkSheetBg = Color(0xFF1B1B22)
    val darkItemBg = Color(0xFF2A2A35)
    val darkIconBg = Color(0xFF353642)
    val textWhite = Color.White
    val textGray = Color(0xFFA0A0AB)
    val primaryColor = MaterialTheme.colorScheme.primary

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(darkSheetBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Title Header
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Profile",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = textWhite
                )
                Text(
                    text = "Manage your account, membership, settings, and more",
                    style = MaterialTheme.typography.bodyMedium,
                    color = textGray
                )
            }
        }

        // Account Section
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToTab?.invoke(com.example.data.model.AppTab.AUTH) },
                colors = CardDefaults.cardColors(containerColor = darkItemBg),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = primaryColor,
                            modifier = Modifier.size(56.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = textWhite,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = "Sign In / Sign Up",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = textWhite
                            )
                            Text(
                                text = "Sync bookmarks and progress",
                                style = MaterialTheme.typography.bodySmall,
                                color = textGray
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Go",
                        tint = textGray
                    )
                }
            }
        }

        // Premium Membership Section
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToTab?.invoke(com.example.data.model.AppTab.PREMIUM) },
                colors = CardDefaults.cardColors(
                    containerColor = if (uiState.isPremiumUser) Color(0xFF1B2A24) else darkItemBg
                ),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                border = if (uiState.isPremiumUser) androidx.compose.foundation.BorderStroke(1.dp, GoldAccentLight.copy(alpha = 0.5f)) else null
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(if (uiState.isPremiumUser) GoldAccentLight.copy(alpha = 0.2f) else darkIconBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (uiState.isPremiumUser) Icons.Default.Check else Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (uiState.isPremiumUser) GoldAccentLight else textGray,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = if (uiState.isPremiumUser) "Quran Premium Active" else "Unlock Premium",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (uiState.isPremiumUser) GoldAccentLight else textWhite
                            )
                            Text(
                                text = if (uiState.isPremiumUser) "All features unlocked" else "Start 7-day free trial",
                                style = MaterialTheme.typography.bodySmall,
                                color = textGray
                            )
                        }
                    }
                    if (!uiState.isPremiumUser) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = primaryColor
                        ) {
                            Text(
                                text = "Try Free",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = textWhite,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Settings Section
        item {
            Text(
                text = "Preferences",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = textWhite,
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
            )
        }
        
        // Settings: Font Size
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = darkItemBg)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.FormatSize, contentDescription = null, tint = primaryColor)
                        Text("Arabic Font Size", fontWeight = FontWeight.Bold, color = textWhite)
                    }
                    
                    Surface(
                        color = darkIconBg,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
                            fontFamily = AmiriFontFamily,
                            fontSize = uiState.arabicFontSizeSp.sp,
                            textAlign = TextAlign.Center,
                            color = textWhite,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("A", fontSize = 16.sp, color = textGray)
                        Slider(
                            value = uiState.arabicFontSizeSp,
                            onValueChange = onUpdateFontSize,
                            valueRange = 24f..48f,
                            steps = 6,
                            modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = primaryColor,
                                activeTrackColor = primaryColor,
                                inactiveTrackColor = darkIconBg
                            )
                        )
                        Text("A", fontSize = 24.sp, color = textGray)
                    }
                }
            }
        }

        // Settings: Translation
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = darkItemBg)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Language, contentDescription = null, tint = primaryColor)
                        Text("Translation Language", fontWeight = FontWeight.Bold, color = textWhite)
                    }
                    
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        TranslationLanguage.values().forEach { lang ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onSelectTranslationLanguage(lang) }
                                    .background(if (uiState.translationLanguage == lang) primaryColor.copy(alpha = 0.2f) else Color.Transparent)
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = lang.displayName,
                                    color = if (uiState.translationLanguage == lang) textWhite else textGray,
                                    fontWeight = if (uiState.translationLanguage == lang) FontWeight.Bold else FontWeight.Normal
                                )
                                RadioButton(
                                    selected = uiState.translationLanguage == lang,
                                    onClick = { onSelectTranslationLanguage(lang) },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = primaryColor,
                                        unselectedColor = textGray
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Settings: Theme
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = darkItemBg)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(imageVector = Icons.Default.Palette, contentDescription = null, tint = primaryColor)
                            Text("Visual Theme", fontWeight = FontWeight.Bold, color = textWhite)
                        }
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemeOptionCard(
                            title = "System",
                            icon = Icons.Default.SettingsSuggest,
                            isSelected = uiState.darkModeOption == DarkModeOption.SYSTEM,
                            onClick = { onSelectDarkMode(DarkModeOption.SYSTEM) },
                            modifier = Modifier.weight(1f),
                            darkItemBg = darkIconBg,
                            primaryColor = primaryColor,
                            textWhite = textWhite,
                            textGray = textGray
                        )
                        ThemeOptionCard(
                            title = "Light",
                            icon = Icons.Default.LightMode,
                            isSelected = uiState.darkModeOption == DarkModeOption.LIGHT,
                            onClick = { onSelectDarkMode(DarkModeOption.LIGHT) },
                            modifier = Modifier.weight(1f),
                            darkItemBg = darkIconBg,
                            primaryColor = primaryColor,
                            textWhite = textWhite,
                            textGray = textGray
                        )
                        ThemeOptionCard(
                            title = "Dark",
                            icon = Icons.Default.DarkMode,
                            isSelected = uiState.darkModeOption == DarkModeOption.DARK,
                            onClick = { onSelectDarkMode(DarkModeOption.DARK) },
                            modifier = Modifier.weight(1f),
                            darkItemBg = darkIconBg,
                            primaryColor = primaryColor,
                            textWhite = textWhite,
                            textGray = textGray
                        )
                    }
                }
            }
        }

        // About & Support Section
        item {
            Text(
                text = "About & Support",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = textWhite,
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = darkItemBg),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column {
                    AboutRow(icon = Icons.Default.Info, title = "About App", description = "Version 1.0.0", textWhite = textWhite, textGray = textGray)
                    HorizontalDivider(color = darkIconBg)
                    AboutRow(icon = Icons.Default.Star, title = "Rate Us", description = "Love the app? Leave a review", textWhite = textWhite, textGray = textGray)
                    HorizontalDivider(color = darkIconBg)
                    AboutRow(icon = Icons.Default.Share, title = "Share with Friends", description = "Share the rewards", textWhite = textWhite, textGray = textGray)
                    HorizontalDivider(color = darkIconBg)
                    AboutRow(icon = Icons.AutoMirrored.Filled.Help, title = "Help & Support", description = "Contact our support team", textWhite = textWhite, textGray = textGray)
                }
            }
        }
    }
}

@Composable
private fun ThemeOptionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    darkItemBg: Color,
    primaryColor: Color,
    textWhite: Color,
    textGray: Color
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) primaryColor.copy(alpha = 0.15f) else darkItemBg
        ),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, primaryColor) else null
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) primaryColor else textGray,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) textWhite else textGray
            )
        }
    }
}

@Composable
private fun AboutRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    textWhite: Color,
    textGray: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { /* action */ }
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = textGray,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Medium,
                color = textWhite
            )
            if (description.isNotEmpty()) {
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = textGray
                )
            }
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = "Go",
            tint = textGray
        )
    }
}
"""

with open("app/src/main/java/com/example/ui/screens/ProfileScreen.kt", "w") as f:
    f.write(new_content)
