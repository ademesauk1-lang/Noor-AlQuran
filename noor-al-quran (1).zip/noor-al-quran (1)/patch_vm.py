with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "r") as f:
    text = f.read()

import re
text = text.replace('val currentTab: AppTab = AppTab.HOME,', 'val currentTab: AppTab = AppTab.HOME,\n    val isDataLoading: Boolean = true,')

text = text.replace('loadPreferences()', '''loadPreferences()
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            QuranData.initialize(getApplication())
            _uiState.update { it.copy(isDataLoading = false) }
        }''')

with open("app/src/main/java/com/example/ui/state/QuranViewModel.kt", "w") as f:
    f.write(text)
