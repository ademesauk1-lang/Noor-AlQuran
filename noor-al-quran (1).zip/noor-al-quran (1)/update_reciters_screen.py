with open("app/src/main/java/com/example/ui/screens/RecitersScreen.kt", "r") as f:
    content = f.read()

# Make sure imports include CircleShape, CheckCircle, RadioButton, etc.
if "import androidx.compose.material.icons.filled.CheckCircle" not in content:
    content = content.replace(
        "import androidx.compose.material.icons.filled.Check",
        "import androidx.compose.material.icons.filled.Check\nimport androidx.compose.material.icons.filled.CheckCircle\nimport androidx.compose.material.icons.filled.RadioButtonUnchecked"
    )

old_card = """@Composable
private fun ReciterItemCard(
    qari: Qari,
    index: Int,
    isSelected: Boolean,
    isLocked: Boolean,
    onSelect: () -> Unit,
    onPlayPreview: () -> Unit,
    darkItemBg: Color,
    darkIconBg: Color,
    textWhite: Color,
    textLight: Color,
    textGray: Color
) {"""

# Replace ReciterItemCard body
card_start = content.find("@Composable\nprivate fun ReciterItemCard")
if card_start != -1:
    new_card_code = """@Composable
private fun ReciterItemCard(
    qari: Qari,
    index: Int,
    isSelected: Boolean,
    isLocked: Boolean,
    onSelect: () -> Unit,
    onPlayPreview: () -> Unit,
    darkItemBg: Color,
    darkIconBg: Color,
    textWhite: Color,
    textLight: Color,
    textGray: Color
) {
    val avatarModel: Any = qari.imageResId 
        ?: if (qari.photoUrl.isNotBlank()) qari.photoUrl 
        else "https://images.unsplash.com/photo-1542838132-92c53300491e?w=300&q=80"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .testTag("reciter_card_${qari.id}"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) darkItemBg else Color.Transparent
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 16.dp)
                .then(if (isLocked) Modifier.alpha(0.6f) else Modifier),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Reciter Image - Always showing real image or guaranteed portrait
                AsyncImage(
                    model = avatarModel,
                    contentDescription = qari.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(darkIconBg)
                        .then(if (isSelected) Modifier.border(2.dp, textWhite, CircleShape) else Modifier)
                )

                Spacer(modifier = Modifier.width(16.dp))

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = qari.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) textWhite else textLight
                    )
                    Text(
                        text = "${qari.country} • Murattal",
                        style = MaterialTheme.typography.bodyMedium,
                        color = textGray
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            if (isLocked) {
                Icon(
                    imageVector = Icons.Default.WorkspacePremium,
                    contentDescription = "Premium Reciter",
                    tint = com.example.ui.theme.GoldAccentLight,
                    modifier = Modifier.size(24.dp)
                )
            } else if (isSelected) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Selected Reciter",
                    tint = textWhite,
                    modifier = Modifier.size(28.dp)
                )
            } else {
                Icon(
                    imageVector = Icons.Default.RadioButtonUnchecked,
                    contentDescription = "Select Reciter",
                    tint = textGray,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}"""
    content = content[:card_start] + new_card_code
    with open("app/src/main/java/com/example/ui/screens/RecitersScreen.kt", "w") as f:
        f.write(content)
    print("RecitersScreen.kt updated successfully")
else:
    print("Could not find ReciterItemCard")
